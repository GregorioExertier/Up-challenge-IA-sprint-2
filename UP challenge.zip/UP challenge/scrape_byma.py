"""Script en Python para realizar web scraping de la página de BYMA.
Este script intenta recuperar el HTML de la dirección indicada y guardar una copia local
con algunas inferencias. En un entorno real se puede ampliar con Selenium si el contenido
se carga con JavaScript.
"""

import json
import os
from datetime import datetime

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    raise SystemExit('Instala las dependencias con: pip install requests beautifulsoup4')

DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')
OUTPUT_FILE = os.path.join(DATA_DIR, 'byma_scrape.json')
URL = 'https://open.bymadata.com.ar/#/dashboard'

os.makedirs(DATA_DIR, exist_ok=True)

print(f'Iniciando scraping de BYMA: {URL}')
response = requests.get(URL, timeout=20)
response.raise_for_status()

soup = BeautifulSoup(response.text, 'html.parser')

# Intentamos extraer títulos y posibles variables que aparezcan en la página.
titles = [tag.get_text(strip=True) for tag in soup.find_all(['h1', 'h2', 'h3', 'title'])]
links = [a.get('href') for a in soup.find_all('a', href=True)]

scrape_data = {
    'timestamp': datetime.utcnow().isoformat() + 'Z',
    'url': URL,
    'status_code': response.status_code,
    'page_title': soup.title.string if soup.title else None,
    'titles': titles,
    'links': links,
    'raw_html_length': len(response.text)
}

with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
    json.dump(scrape_data, f, ensure_ascii=False, indent=2)

print(f'Scraping guardado en {OUTPUT_FILE}')
