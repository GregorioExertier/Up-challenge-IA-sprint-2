#!/usr/bin/env python3
"""Script para actualizar productos con características"""

import json
import os

DATA_DIR = 'data'
PRODUCTS_FILE = os.path.join(DATA_DIR, 'products.json')

# Mapeo de características por tipo de producto
CHARACTERISTICS_MAP = {
    # Acciones argentinas
    'YPF': ['char_risk_medio', 'char_country_ar', 'char_type_rentavariable', 'char_type_acciones'],
    'GGAL': ['char_risk_medio', 'char_country_ar', 'char_type_rentavariable', 'char_type_acciones'],
    'PAMP': ['char_risk_bajo', 'char_country_ar', 'char_type_rentavariable', 'char_type_acciones'],
    'TXAR': ['char_risk_alto', 'char_country_ar', 'char_type_rentavariable', 'char_type_acciones'],
    'BBAR': ['char_risk_medio', 'char_country_ar', 'char_type_rentavariable', 'char_type_acciones'],
    'SUPV': ['char_risk_medio', 'char_country_ar', 'char_type_rentavariable', 'char_type_acciones'],
    'COME': ['char_risk_bajo', 'char_country_ar', 'char_type_rentavariable', 'char_type_acciones'],
    
    # CEDEARs
    'AAPL': ['char_risk_alto', 'char_country_usa', 'char_type_rentavariable', 'char_type_cedear'],
    'TSLA': ['char_risk_alto', 'char_country_usa', 'char_type_rentavariable', 'char_type_cedear'],
    'SPY': ['char_risk_medio', 'char_country_global', 'char_type_rentavariable', 'char_type_cedear'],
    'KO': ['char_risk_bajo', 'char_country_usa', 'char_type_rentavariable', 'char_type_cedear'],
    'MSFT': ['char_risk_alto', 'char_country_usa', 'char_type_rentavariable', 'char_type_cedear'],
    'NVDA': ['char_risk_alto', 'char_country_usa', 'char_type_rentavariable', 'char_type_cedear'],
    'AMZN': ['char_risk_alto', 'char_country_usa', 'char_type_rentavariable', 'char_type_cedear'],
    'META': ['char_risk_alto', 'char_country_usa', 'char_type_rentavariable', 'char_type_cedear'],
    
    # Títulos Públicos
    'AL29': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    'AL30': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    'AL35': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    'GD29': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    'GD30': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    'GD35': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    'T2X4': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    'TX26': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    'TX28': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    'TO26': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    'TO28': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    'TDA24': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    'TDG26': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    
    # Obligaciones Negociables
    'YPFON2030': ['char_risk_medio', 'char_country_ar', 'char_type_rentafija'],
    'PAMPON': ['char_risk_medio', 'char_country_ar', 'char_type_rentafija'],
    'IRSAON': ['char_risk_medio', 'char_country_ar', 'char_type_rentafija'],
    'VISTAENERGYBOND': ['char_risk_medio', 'char_country_ar', 'char_type_rentafija'],
    'TELECOMBOND': ['char_risk_medio', 'char_country_ar', 'char_type_rentafija'],
    
    # Cauciones
    'CAU1D': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    'CAU7D': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    'CAU30D': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    'CAU90D': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
    
    # Opciones
    'CALLPAMP': ['char_risk_alto', 'char_country_ar', 'char_type_opciones'],
    'PUTYPF': ['char_risk_alto', 'char_country_ar', 'char_type_opciones'],
    'CALLYPF': ['char_risk_alto', 'char_country_ar', 'char_type_opciones'],
    'PUTGGAL': ['char_risk_alto', 'char_country_ar', 'char_type_opciones'],
    
    # Futuros
    'DLR0626': ['char_risk_alto', 'char_country_ar', 'char_type_futuros'],
    'IMV0626': ['char_risk_alto', 'char_country_ar', 'char_type_futuros'],
    'SOJ0726': ['char_risk_alto', 'char_country_ar', 'char_type_futuros'],
    
    # Fondos
    'FMMG': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija', 'char_type_fondos'],
    'FRFBBVA': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija', 'char_type_fondos'],
    'FCER': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija', 'char_type_fondos'],
    'FDLD': ['char_risk_bajo', 'char_country_global', 'char_type_rentafija', 'char_type_fondos'],
    'FACC': ['char_risk_medio', 'char_country_ar', 'char_type_rentavariable', 'char_type_fondos'],
    'FGLO': ['char_risk_medio', 'char_country_global', 'char_type_rentavariable', 'char_type_fondos'],
}

def update_products():
    try:
        with open(PRODUCTS_FILE, 'r', encoding='utf-8-sig') as f:
            products = json.load(f)
        
        updated = 0
        for product in products:
            if 'characteristics' not in product:
                characteristics = CHARACTERISTICS_MAP.get(product['id'], [])
                if characteristics:
                    product['characteristics'] = characteristics
                    updated += 1
        
        with open(PRODUCTS_FILE, 'w', encoding='utf-8') as f:
            json.dump(products, f, indent=2, ensure_ascii=False)
        
        print(f'✅ Actualización completada')
        print(f'   {updated} productos actualizados con características')
    except Exception as e:
        print(f'❌ Error al actualizar productos: {e}')
        exit(1)

if __name__ == '__main__':
    update_products()
