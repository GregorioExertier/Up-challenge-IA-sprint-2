// Script para la administración de características

let allCharacteristics = [];
let editingId = null;

async function loadCharacteristics() {
  const listContainer = document.getElementById('characteristics-list');
  const alertContainer = document.getElementById('alert-container');

  try {
    // Verificar si es admin
    if (!isAdminUser()) {
      showMessage(alertContainer, 'Solo administradores pueden acceder a esta página', 'error');
      setTimeout(() => {
        window.location.href = 'index.html';
      }, 2000);
      return;
    }

    const response = await fetchJsonWithRetry(`${API_BASE}/admin/characteristics`, {
      headers: authHeaders()
    });

    allCharacteristics = response.characteristics || [];

    if (allCharacteristics.length === 0) {
      listContainer.innerHTML = '<div class="empty-state"><p>No hay características registradas</p></div>';
      return;
    }

    renderCharacteristics();
  } catch (error) {
    listContainer.innerHTML = '<div class="empty-state"><p>Error cargando características: ' + error.message + '</p></div>';
  }
}

function renderCharacteristics() {
  const listContainer = document.getElementById('characteristics-list');

  if (allCharacteristics.length === 0) {
    listContainer.innerHTML = '<div class="empty-state"><p>No hay características registradas</p></div>';
    return;
  }

  // Agrupar por categoría
  const byCategory = {};
  allCharacteristics.forEach((char) => {
    const cat = char.category || 'other';
    if (!byCategory[cat]) byCategory[cat] = [];
    byCategory[cat].push(char);
  });

  const categoryNames = {
    risk: 'Riesgo',
    country: 'País/Región',
    type: 'Tipo de instrumento',
    other: 'Otro'
  };

  let html = '';
  Object.keys(byCategory)
    .sort()
    .forEach((cat) => {
      html += `<div style="margin-bottom: 20px;">
        <h4 style="color: #7ED321; margin-bottom: 10px;">${categoryNames[cat] || cat}</h4>
        ${byCategory[cat]
          .map((char) => createCharacteristicCard(char))
          .join('')}
      </div>`;
    });

  listContainer.innerHTML = html;

  // Agregar listeners
  document.querySelectorAll('.btn-edit-char').forEach((btn) => {
    btn.addEventListener('click', () => editCharacteristic(btn.dataset.charId));
  });

  document.querySelectorAll('.btn-delete-char').forEach((btn) => {
    btn.addEventListener('click', () => deleteCharacteristic(btn.dataset.charId));
  });
}

function createCharacteristicCard(char) {
  return `
    <div class="characteristic-card" data-char-id="${char.id}">
      <div class="char-icon">${char.icon}</div>
      <div class="char-info">
        <div class="char-name">
          ${char.name}
          <span class="category-tag">${char.category}</span>
        </div>
        <div class="char-meta">${char.description || 'Sin descripción'}</div>
      </div>
      <div class="char-actions">
        <button class="btn-edit-char" data-char-id="${char.id}">✏️ Editar</button>
        <button class="btn-delete-char" data-char-id="${char.id}">🗑️ Eliminar</button>
      </div>
    </div>
  `;
}

function editCharacteristic(charId) {
  const char = allCharacteristics.find((c) => c.id === charId);
  if (!char) return;

  editingId = charId;
  const form = document.getElementById('characteristics-form');
  form.elements['characteristicId'].value = charId;
  form.elements['name'].value = char.name;
  form.elements['icon'].value = char.icon;
  form.elements['category'].value = char.category;
  form.elements['description'].value = char.description || '';

  // Mostrar botón de cancelar
  document.getElementById('btn-cancel-form').classList.remove('hidden');

  // Cambiar título del formulario
  const formSection = document.getElementById('form-section');
  formSection.querySelector('h3').textContent = 'Editar característica';

  // Cambiar texto del botón
  const submitBtn = form.querySelector('.btn-submit-char');
  submitBtn.textContent = 'Guardar cambios';

  // Scroll al formulario
  formSection.scrollIntoView({ behavior: 'smooth' });
}

function cancelEditCharacteristic() {
  editingId = null;
  const form = document.getElementById('characteristics-form');
  form.reset();

  document.getElementById('btn-cancel-form').classList.add('hidden');
  const formSection = document.getElementById('form-section');
  formSection.querySelector('h3').textContent = 'Agregar nueva característica';
  form.querySelector('.btn-submit-char').textContent = 'Guardar característica';
}

async function deleteCharacteristic(charId) {
  if (!confirm('¿Estás seguro de que deseas eliminar esta característica?')) {
    return;
  }

  const alertContainer = document.getElementById('alert-container');

  try {
    const response = await fetchJsonWithRetry(`${API_BASE}/admin/characteristics/${charId}`, {
      method: 'DELETE',
      headers: authHeaders()
    });

    // Remover de la lista local
    allCharacteristics = allCharacteristics.filter((c) => c.id !== charId);
    renderCharacteristics();

    showMessage(alertContainer, response.message || 'Característica eliminada correctamente', 'success');
  } catch (error) {
    showMessage(alertContainer, 'Error al eliminar: ' + error.message, 'error');
  }
}

async function handleFormSubmit(e) {
  e.preventDefault();
  const alertContainer = document.getElementById('alert-container');
  const form = e.target;

  const charId = form.elements['characteristicId'].value;
  const data = {
    name: form.elements['name'].value,
    icon: form.elements['icon'].value,
    category: form.elements['category'].value,
    description: form.elements['description'].value
  };

  try {
    let response;
    if (editingId) {
      // Editar
      response = await fetchJsonWithRetry(`${API_BASE}/admin/characteristics/${charId}`, {
        method: 'PUT',
        headers: {
          ...authHeaders(),
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });
      
      // Actualizar en la lista local
      const index = allCharacteristics.findIndex((c) => c.id === charId);
      if (index !== -1) {
        allCharacteristics[index] = response.characteristic;
      }
      
      showMessage(alertContainer, response.message || 'Característica actualizada correctamente', 'success');
      cancelEditCharacteristic();
    } else {
      // Crear
      response = await fetchJsonWithRetry(`${API_BASE}/admin/characteristics`, {
        method: 'POST',
        headers: {
          ...authHeaders(),
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });

      allCharacteristics.push(response.characteristic);
      showMessage(alertContainer, response.message || 'Característica creada correctamente', 'success');
      form.reset();
    }

    renderCharacteristics();
  } catch (error) {
    showMessage(alertContainer, 'Error: ' + error.message, 'error');
  }
}

// Inicializar cuando el documento esté listo
document.addEventListener('DOMContentLoaded', () => {
  setupHeader();
  loadCharacteristics();

  const form = document.getElementById('characteristics-form');
  form.addEventListener('submit', handleFormSubmit);

  const cancelBtn = document.getElementById('btn-cancel-form');
  cancelBtn.addEventListener('click', cancelEditCharacteristic);
});
