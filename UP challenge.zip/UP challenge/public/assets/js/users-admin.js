// Script para la administración de usuarios

async function loadUsers() {
  const listContainer = document.getElementById('users-list');
  const alertContainer = document.getElementById('alert-container');

  try {
    // Verificar si es el admin principal
    const user = getStoredUser();
    if (!user || (user.username !== 'Roccoadmin67' && user.profile !== 'admin')) {
      showMessage(alertContainer, 'Solo el administrador principal puede acceder a esta página', 'error');
      setTimeout(() => {
        window.location.href = 'index.html';
      }, 2000);
      return;
    }

    const response = await fetchJsonWithRetry(`${API_BASE}/admin/users`, {
      headers: authHeaders()
    });

    if (!response.users || response.users.length === 0) {
      listContainer.innerHTML = '<div class="empty-state"><p>No hay usuarios registrados</p></div>';
      return;
    }

    listContainer.innerHTML = response.users
      .sort((a, b) => {
        // El admin principal primero
        if (a.username === 'Roccoadmin67') return -1;
        if (b.username === 'Roccoadmin67') return 1;
        // Admins después
        if (a.profile === 'admin' && b.profile !== 'admin') return -1;
        if (a.profile !== 'admin' && b.profile === 'admin') return 1;
        // Resto alfabético (por email si no hay username)
        return (a.email || a.username || '').localeCompare(b.email || b.username || '');
      })
      .map((u) => createUserCard(u))
      .join('');

    // Agregar listeners a los botones
    document.querySelectorAll('.btn-toggle-admin').forEach((btn) => {
      btn.addEventListener('click', () => toggleUserAdmin(btn, alertContainer));
    });
  } catch (error) {
    listContainer.innerHTML = '<div class="empty-state"><p>Error cargando usuarios: ' + error.message + '</p></div>';
  }
}

function createUserCard(user) {
  const isAdmin = user.profile === 'admin';
  const isPrincipal = user.username === 'Roccoadmin67';
  const profileText = isAdmin ? 'Admin' : 'Usuario';
  const profileClass = user.profile || 'null';
  const displayName = user.name || user.email || user.username || 'Sin nombre';
  const identifier = user.username ? `@${user.username}` : user.email || 'N/A';

  return `
    <div class="user-card" data-user-id="${user.id}" data-username="${user.username || user.email}">
      <div class="user-info">
        <div class="user-name">
          ${displayName}
          ${isPrincipal ? '<span class="principal-badge">Admin Principal</span>' : ''}
        </div>
        <div class="user-details">
          <strong>${user.username ? 'Usuario:' : 'Email:' }</strong> ${identifier}<br/>
          ${user.investorProfile ? `<strong>Perfil Inversor:</strong> ${user.investorProfile.charAt(0).toUpperCase() + user.investorProfile.slice(1)}<br/>` : ''}
          <strong>Saldo:</strong> ${formatCurrency(user.balance)}<br/>
          <strong>Estado:</strong> <span class="profile-badge ${profileClass}">${profileText}</span>
        </div>
      </div>
      <div style="min-width: 200px; text-align: right; color: rgba(255,255,255,0.6); font-size: 0.9rem;">
        <div><strong>Creado:</strong></div>
        <div>${new Date(user.createdAt).toLocaleDateString('es-AR')}</div>
      </div>
      <div class="user-actions">
        ${isPrincipal
          ? '<span style="color: #FFD700; font-weight: 600;">Admin Principal</span>'
          : `<button class="btn-toggle-admin ${isAdmin ? '' : 'make-admin'}" data-user-id="${user.id}">
              ${isAdmin ? '❌ Remover Admin' : '✅ Hacer Admin'}
            </button>`
        }
      </div>
    </div>
  `;
}

async function toggleUserAdmin(btn, alertContainer) {
  const userId = btn.dataset.userId;
  const userCard = btn.closest('.user-card');
  const username = userCard.dataset.username;
  const currentProfile = btn.classList.contains('make-admin') ? null : 'admin';
  const newProfile = currentProfile === 'admin' ? null : 'admin';

  try {
    btn.disabled = true;
    btn.textContent = 'Procesando...';

    const response = await fetchJsonWithRetry(`${API_BASE}/admin/users/${userId}/profile`, {
      method: 'PUT',
      headers: {
        ...authHeaders(),
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ profile: newProfile })
    });

    // Actualizar el botón y la tarjeta
    const actionText = newProfile === 'admin' ? '❌ Remover Admin' : '✅ Hacer Admin';
    btn.textContent = actionText;
    btn.classList.toggle('make-admin');

    // Actualizar el badge de perfil
    const profileBadge = userCard.querySelector('.profile-badge');
    const profileText = newProfile === 'admin' ? 'Admin' : 'Usuario';
    profileBadge.textContent = profileText;
    profileBadge.className = `profile-badge ${newProfile || 'null'}`;

    showMessage(
      alertContainer,
      `${username} ahora es ${newProfile === 'admin' ? 'administrador' : 'usuario regular'}.`,
      'success'
    );
  } catch (error) {
    showMessage(alertContainer, 'Error: ' + error.message, 'error');
    btn.disabled = false;
    btn.textContent = btn.classList.contains('make-admin') ? '✅ Hacer Admin' : '❌ Remover Admin';
  }
}

// Inicializar cuando el documento esté listo
document.addEventListener('DOMContentLoaded', () => {
  setupHeader();
  loadUsers();
});
