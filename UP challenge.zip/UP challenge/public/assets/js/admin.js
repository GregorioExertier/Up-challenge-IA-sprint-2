// Script para el panel administrativo - gestión de productos y tabs

let allCharacteristics = [];

// Funcionalidad de tabs
document.addEventListener('DOMContentLoaded', () => {
  setupHeader();
  setupTabs();
  setupAdminForm();
  loadCharacteristicsForSelector();
  loadAdminList();
});

function setupTabs() {
  const tabs = document.querySelectorAll('.admin-tab');
  const contents = document.querySelectorAll('.tab-content');

  tabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      const tabName = tab.dataset.tab;

      // Remover clase active de todos
      tabs.forEach((t) => t.classList.remove('active'));
      contents.forEach((c) => c.classList.remove('active'));

      // Agregar clase active al clickeado
      tab.classList.add('active');
      document.getElementById(`${tabName}-tab`).classList.add('active');
    });
  });
}

async function loadCharacteristicsForSelector() {
  try {
    const response = await fetchJsonWithRetry(`${API_BASE}/characteristics`);
    allCharacteristics = response.characteristics || [];
    renderCharacteristicsSelector();
  } catch (error) {
    console.warn('Error loading characteristics:', error.message);
  }
}

function renderCharacteristicsSelector() {
  const selector = document.getElementById('characteristics-selector');
  
  if (allCharacteristics.length === 0) {
    selector.innerHTML = '<p style="color: rgba(255,255,255,0.5); font-size: 0.9rem;">No hay características disponibles</p>';
    return;
  }

  // Agrupar por categoría
  const byCategory = {};
  allCharacteristics.forEach((char) => {
    const cat = char.category || 'other';
    if (!byCategory[cat]) byCategory[cat] = [];
    byCategory[cat].push(char);
  });

  const categoryNames = {
    risk: '⚖️ Nivel de Riesgo',
    country: '🌍 País/Región',
    type: '📊 Tipo de Instrumento',
    other: 'Otro'
  };

  let html = '<label style="font-weight: 600; margin-bottom: 15px; display: block; font-size: 1.05rem;">Características del producto (elige máximo 1 por categoría):</label>';
  html += '<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px;">';

  Object.keys(byCategory)
    .sort()
    .forEach((cat) => {
      html += `
        <div style="border: 2px solid rgba(126, 211, 33, 0.2); border-radius: 10px; padding: 15px; background: rgba(126, 211, 33, 0.08); transition: all 0.3s ease;">
          <h4 style="color: #7ED321; font-weight: 700; margin: 0 0 12px 0; font-size: 0.95rem;">${categoryNames[cat] || cat}</h4>
          <div style="display: flex; flex-direction: column; gap: 10px;">
      `;

      byCategory[cat].forEach((char) => {
        const inputId = `char_${char.id}`;
        html += `
          <label style="display: flex; align-items: center; cursor: pointer; padding: 8px 10px; border-radius: 6px; transition: all 0.2s ease; background: rgba(255,255,255,0.02);" onmouseover="this.style.background='rgba(126, 211, 33, 0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.02)'">
            <input 
              type="radio" 
              id="${inputId}" 
              name="char_${cat}" 
              value="${char.id}"
              style="cursor: pointer; width: 16px; height: 16px; margin-right: 10px;"
            />
            <span style="display: flex; align-items: center; gap: 8px; flex: 1;">
              <span style="font-size: 1.3rem;">${char.icon}</span>
              <span style="font-size: 0.9rem; font-weight: 500;">${char.name}</span>
            </span>
          </label>
        `;
      });

      html += `
          </div>
        </div>
      `;
    });

  html += '</div>';
  selector.innerHTML = html;
}

function setupAdminForm() {
  const form = document.getElementById('admin-form');
  form.addEventListener('submit', handleFormSubmit);
}

async function handleFormSubmit(e) {
  e.preventDefault();

  const productId = e.target.elements['productId'].value;
  
  // Recopilar características seleccionadas (desde radio buttons)
  const form = e.target;
  const characteristics = [];
  
  // Buscar todos los radio buttons seleccionados (nombres con patrón char_*)
  const radios = form.querySelectorAll('input[type="radio"][name^="char_"]:checked');
  radios.forEach((radio) => {
    if (radio.value) {
      characteristics.push(radio.value);
    }
  });

  const data = {
    name: form.elements['name'].value,
    symbol: form.elements['symbol'].value,
    type: form.elements['type'].value,
    price: form.elements['price'].value,
    image: form.elements['image'].value,
    category: form.elements['category'].value,
    subCategory: form.elements['subCategory'].value,
    featured: form.elements['featured'].value,
    description: form.elements['description'].value,
    details: form.elements['details'].value,
    characteristics: characteristics
  };

  try {
    let response;
    if (productId) {
      // Editar
      response = await fetchJsonWithRetry(`${API_BASE}/admin/products/${productId}`, {
        method: 'PUT',
        headers: {
          ...authHeaders(),
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });
    } else {
      // Crear
      response = await fetchJsonWithRetry(`${API_BASE}/admin/products`, {
        method: 'POST',
        headers: {
          ...authHeaders(),
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });
    }

    alert(response.message);
    form.reset();
    form.elements['productId'].value = '';
    loadAdminList();
  } catch (error) {
    alert('Error: ' + error.message);
  }
}

async function loadAdminList() {
  const listContainer = document.getElementById('admin-list');

  try {
    const { products } = await fetchJsonWithRetry(`${API_BASE}/products?limit=100`);
    if (!products || products.length === 0) {
      listContainer.innerHTML = '<p>No hay productos</p>';
      return;
    }

    listContainer.innerHTML = products
      .map((product) => createProductCard(product))
      .join('');

    // Agregar listeners
    document.querySelectorAll('.btn-edit-product').forEach((btn) => {
      btn.addEventListener('click', () => editProduct(btn.dataset.productId));
    });

    document.querySelectorAll('.btn-delete-product').forEach((btn) => {
      btn.addEventListener('click', () => deleteProduct(btn.dataset.productId));
    });
  } catch (error) {
    listContainer.innerHTML = '<p>Error cargando productos: ' + error.message + '</p>';
  }
}

function createProductCard(product) {
  return `
    <div class="card" style="position: relative;">
      <img src="${product.image || 'assets/images/product-placeholder.svg'}" alt="${product.name}" style="width: 100%; height: 150px; object-fit: cover; border-radius: 8px; margin-bottom: 10px;" />
      <h4>${product.name} (${product.symbol})</h4>
      <p style="font-size: 0.9rem; color: rgba(255,255,255,0.7);">${product.description}</p>
      <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 10px;">
        <strong>${formatCurrency(product.price)}</strong>
        <div style="display: flex; gap: 5px;">
          <button class="btn-edit-product" data-product-id="${product.id}" style="padding: 5px 10px; background: #6BA3D4; border: none; color: white; border-radius: 4px; cursor: pointer;">✏️</button>
          <button class="btn-delete-product" data-product-id="${product.id}" style="padding: 5px 10px; background: #c15454; border: none; color: white; border-radius: 4px; cursor: pointer;">🗑️</button>
        </div>
      </div>
    </div>
  `;
}

async function editProduct(productId) {
  try {
    const product = await fetchJsonWithRetry(`${API_BASE}/products/${productId}`);

    const form = document.getElementById('admin-form');
    form.elements['productId'].value = product.id;
    form.elements['name'].value = product.name;
    form.elements['symbol'].value = product.symbol;
    form.elements['type'].value = product.type;
    form.elements['price'].value = product.price;
    form.elements['image'].value = product.image;
    form.elements['category'].value = product.category;
    form.elements['subCategory'].value = product.subCategory;
    form.elements['featured'].value = product.featured;
    form.elements['description'].value = product.description;
    form.elements['details'].value = product.details;

    // Desmarcar todos los radio buttons
    document.querySelectorAll('input[type="radio"][name^="char_"]').forEach((radio) => {
      radio.checked = false;
    });

    // Marcar los radio buttons de las características del producto
    if (product.characteristics && Array.isArray(product.characteristics)) {
      product.characteristics.forEach((charId) => {
        const radio = document.querySelector(`input[type="radio"][value="${charId}"]`);
        if (radio) radio.checked = true;
      });
    }

    // Cambiar el botón de submit
    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.textContent = 'Actualizar producto';
    submitBtn.style.background = 'linear-gradient(135deg, #FFD700, #FFA500)';
    submitBtn.style.color = 'black';

    // Scroll al formulario
    document.getElementById('products-tab').scrollIntoView({ behavior: 'smooth' });
  } catch (error) {
    alert('Error: ' + error.message);
  }
}

async function deleteProduct(productId) {
  if (!confirm('¿Estás seguro de que deseas eliminar este producto?')) {
    return;
  }

  try {
    const response = await fetchJsonWithRetry(`${API_BASE}/admin/products/${productId}`, {
      method: 'DELETE',
      headers: authHeaders()
    });

    alert(response.message);
    loadAdminList();
  } catch (error) {
    alert('Error: ' + error.message);
  }
}
