// Script para mostrar detalles del producto con características

let allCharacteristicsMap = {};

// Marcar que este script manejará la página de producto
window.productPageLoaded = true;

document.addEventListener('DOMContentLoaded', async () => {
  setupHeader();
  
  // Cargar características primero
  await loadCharacteristics();
  
  // Luego cargar el producto
  const productId = getQueryParam('id');
  if (productId) {
    loadProductDetail(productId);
  }
});

async function loadCharacteristics() {
  try {
    const response = await fetchJsonWithRetry(`${API_BASE}/characteristics`);
    const characteristics = response.characteristics || [];
    characteristics.forEach((char) => {
      allCharacteristicsMap[char.id] = char;
    });
  } catch (error) {
    console.warn('Error loading characteristics:', error.message);
  }
}

async function loadProductDetail(productId) {
  const container = document.getElementById('product-detail');
  
  try {
    const product = await fetchJsonWithRetry(`${API_BASE}/products/${productId}`);
    
    let characteristicsHtml = '';
    if (product.characteristics && product.characteristics.length > 0) {
      const characteristics = product.characteristics
        .map((charId) => allCharacteristicsMap[charId])
        .filter((c) => c); // Filtrar características que no existan

      if (characteristics.length > 0) {
        characteristicsHtml = `
          <div class="characteristics-block">
            <h3>⚙️ Características</h3>
            <div class="characteristics-grid">
              ${characteristics
                .map((char) => `
                  <div class="characteristic-item">
                    <div class="characteristic-icon">${char.icon}</div>
                    <div class="characteristic-name">${char.name}</div>
                    <div class="characteristic-category">${char.category}</div>
                  </div>
                `)
                .join('')}
            </div>
          </div>
        `;
      }
    }

    const riskLevel = product.risk || determineProductRisk(product);

    container.innerHTML = `
      <div class="card">
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 30px; align-items: start;">
          <div>
            <img src="${product.image || 'assets/images/product-placeholder.svg'}" alt="${product.name}" style="width:100%; border-radius:12px; margin-bottom:20px;" />
          </div>
          <div>
            <h2 style="margin-top: 0;">${product.name}</h2>
            <p style="font-size: 1.2rem; color: #7ED321; font-weight: 600; margin: 10px 0;">${formatCurrency(product.price)}</p>
            <p style="color: rgba(255,255,255,0.7); margin-bottom: 20px;">${product.description}</p>
            
            <div style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; padding: 15px; margin-bottom: 20px;">
              <p><strong>Símbolo:</strong> ${product.symbol}</p>
              <p><strong>Tipo:</strong> ${product.type}</p>
              <p><strong>Categoría:</strong> ${product.category} - ${product.subCategory}</p>
              <p><strong>Nivel de riesgo:</strong> <span style="color: ${getRiskColor(riskLevel)}; font-weight: 600;">${riskLevel}</span></p>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
              <button id="btn-buy" class="button primary" style="cursor: pointer;">Comprar</button>
              <button id="btn-sell" class="button" style="cursor: pointer; background: rgba(193, 84, 84, 0.3); color: #FF9999;">Vender</button>
            </div>
          </div>
        </div>

        <hr style="border: none; border-top: 1px solid rgba(255,255,255,0.1); margin: 30px 0;" />

        <h3 style="color: #7ED321;">Información detallada</h3>
        <p>${product.details || 'No hay información disponible'}</p>

        ${characteristicsHtml}

        <div id="modal-operacion" class="modal" style="display: none;">
          <div class="modal-content">
            <header>
              <h2 id="modal-title">Comprar ${product.name}</h2>
              <button class="close" aria-label="Cerrar" id="modal-close">×</button>
            </header>
            <form id="trade-form" style="display: grid; gap: 15px;">
              <div>
                <label>Cantidad</label>
                <input type="number" id="quantity" min="1" placeholder="0" required style="width: 100%; padding: 10px; border: 1px solid rgba(255,255,255,0.2); border-radius: 6px; background: rgba(255,255,255,0.05); color: white;" />
              </div>
              <div>
                <label>Total: <strong id="total-cost">$0</strong></label>
              </div>
              <button type="submit" class="primary">Confirmar operación</button>
            </form>
          </div>
        </div>
      </div>
    `;

    // Event listeners
    const buyBtn = document.getElementById('btn-buy');
    const sellBtn = document.getElementById('btn-sell');
    const modal = document.getElementById('modal-operacion');
    const closeBtn = document.getElementById('modal-close');
    const quantityInput = document.getElementById('quantity');
    const form = document.getElementById('trade-form');

    buyBtn.addEventListener('click', () => {
      document.getElementById('modal-title').textContent = `Comprar ${product.name}`;
      form.dataset.action = 'buy';
      modal.style.display = 'flex';
    });

    sellBtn.addEventListener('click', () => {
      document.getElementById('modal-title').textContent = `Vender ${product.name}`;
      form.dataset.action = 'sell';
      modal.style.display = 'flex';
    });

    closeBtn.addEventListener('click', () => {
      modal.style.display = 'none';
    });

    quantityInput.addEventListener('input', (e) => {
      const quantity = Number(e.target.value) || 0;
      const cost = quantity * product.price;
      document.getElementById('total-cost').textContent = formatCurrency(cost);
    });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      await executeTrade(product.id, quantityInput.value, form.dataset.action);
      modal.style.display = 'none';
    });

    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.style.display = 'none';
      }
    });
  } catch (error) {
    container.innerHTML = `<p style="color: #FF9999;">Error cargando el producto: ${error.message}</p>`;
  }
}

function getRiskColor(risk) {
  const colors = {
    'Bajo': '#7ED321',
    'Medio': '#FFD700',
    'Alto': '#FF6B6B'
  };
  return colors[risk] || '#999';
}

async function executeTrade(assetId, quantity, action) {
  const user = getStoredUser();
  if (!user) {
    alert('Debes iniciar sesión para realizar operaciones');
    return;
  }

  try {
    if (getStoredToken()) {
      // Usar API remota
      const response = await fetchJsonWithRetry(`${API_BASE}/trade`, {
        method: 'POST',
        headers: {
          ...authHeaders(),
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          assetId,
          quantity: Number(quantity),
          action
        })
      });
      
      saveUser(response.user, getStoredToken());
      alert('Operación realizada correctamente');
    } else {
      // Usar operación local
      const result = processLocalTrade(assetId, Number(quantity), action);
      alert('Operación realizada correctamente');
    }
  } catch (error) {
    alert('Error en la operación: ' + error.message);
  }
}

function determineProductRisk(product) {
  const subCategory = String(product.subCategory || '').toLowerCase();
  const type = String(product.type || '').toLowerCase();

  if (['opciones', 'futuros'].includes(subCategory) || ['opción', 'opciones', 'futuro', 'futuros'].includes(type)) {
    return 'Alto';
  }
  if (['títulos públicos', 'cauciones', 'fondos comunes'].includes(subCategory) || ['título público', 'caución', 'fondo'].includes(type)) {
    return 'Bajo';
  }
  return 'Medio';
}
