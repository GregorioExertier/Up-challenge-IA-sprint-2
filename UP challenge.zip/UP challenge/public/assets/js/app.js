const API_BASE = '/api';
const STORAGE_USER = 'broknet-user';
const STORAGE_TOKEN = 'broknet-token';
const LOCAL_USERS_KEY = 'broknet-local-users';
const LOCAL_HISTORY_KEY = 'broknet-history';
const LOCAL_PRODUCTS_KEY = 'broknet-products';

function getStoredUser() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_USER));
  } catch {
    return null;
  }
}

function getStoredToken() {
  return localStorage.getItem(STORAGE_TOKEN);
}

function saveUser(user, token) {
  localStorage.setItem(STORAGE_USER, JSON.stringify(user));
  localStorage.setItem(STORAGE_TOKEN, token);
}

function clearSession() {
  localStorage.removeItem(STORAGE_USER);
  localStorage.removeItem(STORAGE_TOKEN);
}

function getLocalHistory() {
  try {
    return JSON.parse(localStorage.getItem(LOCAL_HISTORY_KEY)) || [];
  } catch {
    return [];
  }
}

function saveLocalHistory(history) {
  localStorage.setItem(LOCAL_HISTORY_KEY, JSON.stringify(history));
}

function addHistoryEntry(type, amount, assetName = null, quantity = null, assetId = null, status = 'success') {
  const history = getLocalHistory();
  const user = getStoredUser();
  history.push({
    id: generateId('trx'),
    userId: user.id,
    type,
    assetId,
    assetName: assetName || (type === 'deposit' ? 'Depósito' : 'Retiro'),
    amount,
    quantity: quantity || null,
    balanceAfter: user.balance,
    status: status,
    date: new Date().toISOString()
  });
  saveLocalHistory(history);
}

function getLocalProducts() {
  try {
    return JSON.parse(localStorage.getItem(LOCAL_PRODUCTS_KEY)) || [];
  } catch {
    return [];
  }
}

function saveLocalProducts(products) {
  localStorage.setItem(LOCAL_PRODUCTS_KEY, JSON.stringify(products));
}

function getAllProducts() {
  const localProducts = getLocalProducts();
  const allProducts = [...FALLBACK_PRODUCTS, ...localProducts];
  // Evitar duplicados por id
  const uniqueMap = new Map();
  allProducts.forEach(p => {
    if (!uniqueMap.has(p.id)) {
      uniqueMap.set(p.id, p);
    }
  });
  return Array.from(uniqueMap.values());
}

function addProduct(product) {
  const products = getLocalProducts();
  products.push(product);
  saveLocalProducts(products);
}

function deleteProduct(productId) {
  const products = getLocalProducts();
  const filtered = products.filter(p => p.id !== productId);
  saveLocalProducts(filtered);
}

function updateProduct(productId, updatedData) {
  const products = getLocalProducts();
  const index = products.findIndex(p => p.id === productId);
  if (index !== -1) {
    products[index] = { ...products[index], ...updatedData };
    saveLocalProducts(products);
  }
}

function processLocalTrade(assetId, quantity, action) {
  const user = getStoredUser();
  const allProducts = getAllProducts();
  const product = allProducts.find(p => p.id === assetId);
  
  if (!product) {
    throw new Error('Activo no encontrado');
  }
  
  if (!['buy', 'sell'].includes(action) || quantity <= 0) {
    throw new Error('Operación inválida');
  }
  
  const price = Number(product.price);
  const cost = price * quantity;
  
  user.portfolio = user.portfolio || {};
  
  if (action === 'buy') {
    if (cost > user.balance) {
      throw new Error('Saldo insuficiente para la compra');
    }
    user.balance -= cost;
    user.portfolio[assetId] = (user.portfolio[assetId] || 0) + quantity;
  } else {
    const owned = user.portfolio[assetId] || 0;
    if (quantity > owned) {
      throw new Error('No posees cantidad suficiente para vender');
    }
    user.balance += cost;
    user.portfolio[assetId] = owned - quantity;
  }
  
  saveUser(user, getStoredToken());
  
  return {
    balance: user.balance,
    portfolio: user.portfolio,
    message: 'Operación realizada'
  };
}

const FALLBACK_PRODUCTS = [
  { id: "YPF", symbol: "YPF", name: "YPF", category: "Renta Variable", subCategory: "Acciones", type: "Acción", description: "Empresa petrolera nacional con fuerte presencia en el mercado.", details: "YPF es una acción representativa de energía local y es útil para simular inversiones en sectores estratégicos.", price: 230, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "GGAL", symbol: "GGAL", name: "GGAL", category: "Renta Variable", subCategory: "Acciones", type: "Acción", description: "Banco con amplio volumen de negociación y datos financieros relevantes.", details: "GGAL permite simular la exposición al sector financiero de Argentina dentro de una estrategia diversificada.", price: 135, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "PAMP", symbol: "PAMP", name: "PAMP", category: "Renta Variable", subCategory: "Acciones", type: "Acción", description: "Empresa agroindustrial líder en el mercado local.", details: "PAMP es ideal para inversores que buscan compañías con exposición internacional y potencial de crecimiento.", price: 480, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "TXAR", symbol: "TXAR", name: "TXAR", category: "Renta Variable", subCategory: "Acciones", type: "Acción", description: "Acción tecnológica con potencial de crecimiento en Argentina.", details: "TXAR representa el sector tecnológico local y es una opción para perfiles moderados y agresivos.", price: 85, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "BBAR", symbol: "BBAR", name: "BBAR", category: "Renta Variable", subCategory: "Acciones", type: "Acción", description: "Banco BBVA Argentina con exposición a servicios financieros domésticos.", details: "BBAR es una de las acciones de la banca local con volumen de negociación relevante en BYMA.", price: 260, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "SUPV", symbol: "SUPV", name: "SUPV", category: "Renta Variable", subCategory: "Acciones", type: "Acción", description: "Empresa de servicios industriales y comercio exterior.", details: "SUPV ofrece un perfil de inversión que captura la recuperación del sector industrial local.", price: 900, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "COME", symbol: "COME", name: "COME", category: "Renta Variable", subCategory: "Acciones", type: "Acción", description: "Compañía alimentaria con presencia local e internacional.", details: "COME es una acción defensiva dentro del mercado argentino.", price: 215, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "AAPL", symbol: "AAPL", name: "AAPL", category: "Renta Variable", subCategory: "CEDEARs", type: "CEDEAR", description: "CEDEAR de Apple que aporta exposición global a tecnología.", details: "AAPL es una opción popular para simular una cartera internacional.", price: 195, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "TSLA", symbol: "TSLA", name: "TSLA", category: "Renta Variable", subCategory: "CEDEARs", type: "CEDEAR", description: "CEDEAR de Tesla, empresa de movilidad eléctrica.", details: "TSLA refleja volatilidad y es ideal para perfiles agresivos.", price: 920, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "SPY", symbol: "SPY", name: "SPY", category: "Renta Variable", subCategory: "CEDEARs", type: "CEDEAR", description: "CEDEAR que replica al ETF S&P 500 para diversificación.", details: "SPY es una alternativa estable con exposición global.", price: 460, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "KO", symbol: "KO", name: "KO", category: "Renta Variable", subCategory: "CEDEARs", type: "CEDEAR", description: "CEDEAR de Coca-Cola, empresa defensiva de consumo masivo.", details: "KO ofrece estabilidad y diversificación internacional.", price: 60, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "MSFT", symbol: "MSFT", name: "MSFT", category: "Renta Variable", subCategory: "CEDEARs", type: "CEDEAR", description: "CEDEAR de Microsoft, líder en software y servicios en la nube.", details: "MSFT es una inversión global con perfil de largo plazo.", price: 310, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "NVDA", symbol: "NVDA", name: "NVDA", category: "Renta Variable", subCategory: "CEDEARs", type: "CEDEAR", description: "CEDEAR de NVIDIA, referente en chips y procesamiento gráfico.", details: "NVDA es ideal para inversores con horizonte largo y apetito por tecnología.", price: 650, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "AMZN", symbol: "AMZN", name: "AMZN", category: "Renta Variable", subCategory: "CEDEARs", type: "CEDEAR", description: "CEDEAR de Amazon, líder en comercio y servicios digitales.", details: "AMZN es perfecto para simular exposición al ecommerce global.", price: 125, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "META", symbol: "META", name: "META", category: "Renta Variable", subCategory: "CEDEARs", type: "CEDEAR", description: "CEDEAR de Meta Platforms, con foco en redes sociales.", details: "META ofrece diversificación en el sector digital y publicidad.", price: 260, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "AL29", symbol: "AL29", name: "AL29", category: "Renta Fija", subCategory: "Títulos Públicos", type: "Título Público", description: "Bono soberano argentino con vencimiento corto.", details: "AL29 es ideal para simular preservación de capital.", price: 105, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "AL30", symbol: "AL30", name: "AL30", category: "Renta Fija", subCategory: "Títulos Públicos", type: "Título Público", description: "Título público en pesos con ajuste por CER.", details: "AL30 protege contra la inflación y es frecuente en carteras conservadoras.", price: 98, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "AL35", symbol: "AL35", name: "AL35", category: "Renta Fija", subCategory: "Títulos Públicos", type: "Título Público", description: "Bono con plazo más largo y componente nominal.", details: "AL35 permite analizar el comportamiento de la deuda de largo plazo.", price: 115, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "GD29", symbol: "GD29", name: "GD29", category: "Renta Fija", subCategory: "Títulos Públicos", type: "Título Público", description: "Bono dólar-linked de corto plazo.", details: "GD29 es útil para simular cobertura en moneda extranjera.", price: 82, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "GD30", symbol: "GD30", name: "GD30", category: "Renta Fija", subCategory: "Títulos Públicos", type: "Título Público", description: "Bono dólar-linked de plazo medio.", details: "GD30 ayuda a diversificar con activos en dólares.", price: 88, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "GD35", symbol: "GD35", name: "GD35", category: "Renta Fija", subCategory: "Títulos Públicos", type: "Título Público", description: "Bono dólar-linked de largo plazo.", details: "GD35 ofrece un ejemplo de protección cambiaria a largo plazo.", price: 103, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "T2X4", symbol: "T2X4", name: "T2X4", category: "Renta Fija", subCategory: "Títulos Públicos", type: "Título Público", description: "Bono corto en pesos con tasa variable.", details: "T2X4 es una alternativa de corto plazo con liquidez y menor riesgo.", price: 101, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "TX26", symbol: "TX26", name: "TX26", category: "Renta Fija", subCategory: "Títulos Públicos", type: "Título Público", description: "Bono ajustado por tasa con vencimiento intermedio.", details: "TX26 es un activo funcional para carteras conservadoras.", price: 95, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "TX28", symbol: "TX28", name: "TX28", category: "Renta Fija", subCategory: "Títulos Públicos", type: "Título Público", description: "Bono con menor plazo y buena liquidez.", details: "TX28 permite comparar distintas duraciones de bonos.", price: 99, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "TO26", symbol: "TO26", name: "TO26", category: "Renta Fija", subCategory: "Títulos Públicos", type: "Título Público", description: "Bono CER con vencimiento medio.", details: "TO26 protege el capital frente a la inflación.", price: 107, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "TO28", symbol: "TO28", name: "TO28", category: "Renta Fija", subCategory: "Títulos Públicos", type: "Título Público", description: "Bono CER de largo plazo.", details: "TO28 ayuda a simular estrategias de preservación del poder adquisitivo.", price: 110, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "TDA24", symbol: "TDA24", name: "TDA24", category: "Renta Fija", subCategory: "Títulos Públicos", type: "Título Público", description: "Bono corto en dólares con baja volatilidad relativa.", details: "TDA24 permite evaluar diferencias entre activos en pesos y dólares.", price: 101, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "TDG26", symbol: "TDG26", name: "TDG26", category: "Renta Fija", subCategory: "Títulos Públicos", type: "Título Público", description: "Bono en dólares con vencimiento medio.", details: "TDG26 es una opción para invertir en deuda pública dolarizada.", price: 99, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "YPFON2030", symbol: "YPF ON 2030", name: "YPF ON 2030", category: "Renta Fija", subCategory: "Obligaciones Negociables", type: "ON", description: "Obligación negociable de YPF con vencimiento 2030.", details: "YPF ON 2030 permite simular deuda corporativa dentro de la cartera.", price: 78, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "PAMPON", symbol: "PAMP ON", name: "PAMP ON", category: "Renta Fija", subCategory: "Obligaciones Negociables", type: "ON", description: "ON de PAMP, empresa agroindustrial clave.", details: "PAMP ON es útil para simular deuda corporativa de consumo y producción.", price: 88, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "IRSAON", symbol: "IRSA ON", name: "IRSA ON", category: "Renta Fija", subCategory: "Obligaciones Negociables", type: "ON", description: "ON de IRSA para simular inversión en bienes raíces.", details: "IRSA ON ofrece una exposición distinta a la deuda corporativa.", price: 45, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "VISTAENERGYBOND", symbol: "ON Vista Energy bond", name: "ON Vista Energy bond", category: "Renta Fija", subCategory: "Obligaciones Negociables", type: "ON", description: "Obligación negociable del sector energético.", details: "VISTAENERGYBOND sirve para aprender sobre deuda en empresas de energía.", price: 74, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "TELECOMBOND", symbol: "ON Telecom Argentina bond", name: "ON Telecom Argentina bond", category: "Renta Fija", subCategory: "Obligaciones Negociables", type: "ON", description: "Obligación negociable de Telecom Argentina.", details: "TELECOMBOND es una alternativa de deuda corporativa en telecomunicaciones.", price: 63, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "CAU1D", symbol: "Caución 1 día", name: "Caución 1 día", category: "Renta Fija", subCategory: "Cauciones", type: "Caución", description: "Depósito a un día para obtener rendimiento inmediato.", details: "CAU1D es útil para simular liquidez y tasas de corto plazo.", price: 1, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "CAU7D", symbol: "Caución 7 días", name: "Caución 7 días", category: "Renta Fija", subCategory: "Cauciones", type: "Caución", description: "Depósito a una semana con retorno predecible.", details: "CAU7D ayuda a analizar la curva de tasa de los depósitos de caución.", price: 1, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "CAU30D", symbol: "Caución 30 días", name: "Caución 30 días", category: "Renta Fija", subCategory: "Cauciones", type: "Caución", description: "Depósito a 30 días, buena opción para gestión de liquidez.", details: "CAU30D es un instrumento de renta fija de muy corto plazo.", price: 1, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "CAU90D", symbol: "Caución 90 días", name: "Caución 90 días", category: "Renta Fija", subCategory: "Cauciones", type: "Caución", description: "Depósito a tres meses para una mayor rentabilidad.", details: "CAU90D ofrece un perfil estable dentro del segmento de cauciones.", price: 1, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "CALLPAMP", symbol: "CALL PAMP", name: "CALL de PAMP", category: "Renta Fija", subCategory: "Opciones", type: "Opción", description: "Opción de compra sobre acción de PAMP.", details: "CALLPAMP permite practicar estrategias de inversión con derivados.", price: 12, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "PUTYPF", symbol: "PUT YPF", name: "PUT de YPF", category: "Renta Fija", subCategory: "Opciones", type: "Opción", description: "Opción de venta sobre acción de YPF.", details: "PUTYPF ayuda a comprender cómo cubrir riesgo en activos volátiles.", price: 8, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "CALLYPF", symbol: "CALL YPF", name: "CALL de YPF", category: "Renta Fija", subCategory: "Opciones", type: "Opción", description: "Opción de compra sobre acción de YPF.", details: "CALLYPF es ideal para simular expectativas alcistas.", price: 14, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "PUTGGAL", symbol: "PUT GGAL", name: "PUT de GGAL", category: "Renta Fija", subCategory: "Opciones", type: "Opción", description: "Opción de venta sobre acción de GGAL.", details: "PUTGGAL permite manejar estrategias de protección en el sector bancario.", price: 9, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "DLR0626", symbol: "DLR0626", name: "DLR0626", category: "Renta Fija", subCategory: "Futuros", type: "Futuro", description: "Contrato futuro de dólar para junio de 2026.", details: "DLR0626 ayuda a entender la cobertura de tipo de cambio en inversiones.", price: 310, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "IMV0626", symbol: "IMV0626", name: "IMV0626", category: "Renta Fija", subCategory: "Futuros", type: "Futuro", description: "Contrato futuro del índice Merval para junio de 2026.", details: "IMV0626 ofrece exposición a la renta variable local mediante futuros.", price: 758, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "SOJ0726", symbol: "SOJ0726", name: "SOJ0726", category: "Renta Fija", subCategory: "Futuros", type: "Futuro", description: "Contrato futuro de soja para julio de 2026.", details: "SOJ0726 permite simular productos agropecuarios dentro de la cartera.", price: 820, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "FMMG", symbol: "Fondo Money Market Galicia", name: "Fondo Money Market Galicia", category: "Renta Fija", subCategory: "Fondos Comunes", type: "Fondo", description: "Fondo común de inversión de mercado monetario para perfil conservador.", details: "Brinda exposición a renta fija de corto plazo con riesgo moderado.", price: 100, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "FRFBBVA", symbol: "Fondo Renta Fija BBVA", name: "Fondo Renta Fija BBVA", category: "Renta Fija", subCategory: "Fondos Comunes", type: "Fondo", description: "Fondo que combina instrumentos de renta fija en pesos.", details: "Es una alternativa para simular carteras conservadoras y obtener rendimientos protegidos.", price: 102, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "FCER", symbol: "Fondo CER Argentina", name: "Fondo CER Argentina", category: "Renta Fija", subCategory: "Fondos Comunes", type: "Fondo", description: "Fondo indexado al CER para protegerse de la inflación.", details: "Ayuda a aprender cómo funcionan los fondos atados al índice de precios.", price: 108, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "FDLD", symbol: "Fondo Dólar Linked", name: "Fondo Dólar Linked", category: "Renta Fija", subCategory: "Fondos Comunes", type: "Fondo", description: "Fondo que sigue la cotización del dólar para diversificación internacional.", details: "Ideal para simular protección ante cambios en el tipo de cambio local.", price: 103, featured: "new", image: "assets/images/product-placeholder.svg" },
  { id: "FACC", symbol: "Fondo Acciones Argentina", name: "Fondo Acciones Argentina", category: "Renta Variable", subCategory: "Fondos Comunes", type: "Fondo", description: "Fondo que invierte en acciones locales de renta variable.", details: "Permite comprender cómo funcionan los fondos que agrupan acciones nacionales.", price: 95, featured: "recommended", image: "assets/images/product-placeholder.svg" },
  { id: "FGLO", symbol: "Fondo Global Argentina", name: "Fondo Global Argentina", category: "Renta Variable", subCategory: "Fondos Comunes", type: "Fondo", description: "Fondo mixto con exposición a renta fija y variable global.", details: "Ayuda a simular carteras balanceadas con exposiciones internacionales.", price: 99, featured: "new", image: "assets/images/product-placeholder.svg" }
];

function authHeaders() {
  const token = getStoredToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function generateId(prefix = 'id') {
  return `${prefix}_${Math.random().toString(36).substring(2, 10)}`;
}

function getLocalUsers() {
  try {
    return JSON.parse(localStorage.getItem(LOCAL_USERS_KEY)) || [];
  } catch {
    return [];
  }
}

function saveLocalUsers(users) {
  localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(users));
}

function normalizeUsername(value) {
  return String(value || '').toLowerCase();
}

// Función para validar correo electrónico
function validateEmail(email) {
  if (!email || !email.includes('@')) {
    return { valid: false, message: 'El correo debe contener @' };
  }
  
  // Dominios permitidos (gTLDs y ccTLDs populares)
  const allowedDomains = [
    // gTLDs
    'com', 'org', 'net', 'edu', 'gov', 'mil', 'info', 'biz', 'pro', 'io', 
    'app', 'dev', 'tech', 'site', 'web', 'online', 'store', 'shop',
    // ccTLDs principales
    'ar', 'com.ar', 'org.ar', 'gov.ar', 'edu.ar',
    'br', 'com.br', 'org.br', 'net.br',
    'cl', 'com.cl', 'org.cl',
    'co', 'com.co', 'org.co',
    'mx', 'com.mx', 'org.mx',
    'pe', 'com.pe', 'org.pe',
    'uy', 'com.uy', 'org.uy',
    'py', 'com.py',
    'bo', 'com.bo',
    've', 'com.ve',
    'ec', 'com.ec',
    'gt', 'com.gt',
    'sv', 'com.sv',
    'hn', 'com.hn',
    'ni', 'com.ni',
    'cr', 'com.cr',
    'pa', 'com.pa',
    'do', 'com.do',
    'cu', 'cu',
    // Otros países
    'us', 'ca', 'uk', 'de', 'fr', 'it', 'es', 'pt', 'nl', 'be', 'ch',
    'au', 'nz', 'jp', 'cn', 'kr', 'in', 'ru', 'ua', 'tr', 'sa', 'ae',
    'eg', 'il', 'za', 'ng', 'ke', 'ma', 'tn', 'dz'
  ];
  
  const emailLower = email.toLowerCase();
  const parts = emailLower.split('@');
  
  if (parts.length !== 2) {
    return { valid: false, message: 'El correo debe tener un solo @' };
  }
  
  const [localPart, domain] = parts;
  
  // Validar que no tenga símbolos raros en la parte local
  const validLocalChars = /^[a-z0-9._+-]+$/;
  if (!validLocalChars.test(localPart) || localPart.length === 0) {
    return { valid: false, message: 'El correo tiene caracteres no permitidos' };
  }
  
  // Validar dominio
  if (!domain || domain.length < 3) {
    return { valid: false, message: 'Dominio de correo inválido' };
  }
  
  // Verificar si termina en un dominio permitido
  const isValidDomain = allowedDomains.some(d => 
    domain === d || domain.endsWith('.' + d)
  );
  
  if (!isValidDomain) {
    return { valid: false, message: 'El correo debe terminar en .com, .org, .net u otro dominio válido' };
  }
  
  return { valid: true };
}

function createLocalUser({ name, lastname, email, password }) {
  // Validar email antes de crear el usuario
  const emailValidation = validateEmail(email);
  if (!emailValidation.valid) {
    throw new Error(emailValidation.message);
  }
  
  const users = getLocalUsers();
  
  // Generar nombre de usuario: 3 primeras letras del nombre + 3 primeras del apellido
  const namePrefix = (name || '').substring(0, 3).toLowerCase();
  const lastnamePrefix = (lastname || '').substring(0, 3).toLowerCase();
  const generatedUsername = namePrefix + lastnamePrefix;
  
  // Verificar si el email ya está registrado
  if (users.some((user) => normalizeUsername(user.email) === normalizeUsername(email))) {
    throw new Error('El correo electrónico ya está registrado.');
  }
  // Verificar si el usuario generado ya existe (agregar número si ya existe)
  let finalUsername = generatedUsername;
  let counter = 1;
  while (users.some((user) => normalizeUsername(user.username) === normalizeUsername(finalUsername))) {
    finalUsername = generatedUsername + counter;
    counter++;
  }
  
  const user = {
    id: generateId('user'),
    name: name,
    lastname: lastname,
    username: finalUsername,
    email: email,
    password,
    balance: 50000,
    profile: null,
    portfolio: {},
    token: generateId('token')
  };
  users.push(user);
  saveLocalUsers(users);
  return { user, token: user.token };
}

function loginLocal({ username, password }) {
  const users = getLocalUsers();
  // Buscar por username, email, o el nombre de usuario generado
  const normalizedInput = normalizeUsername(username);
  const user = users.find((item) => 
    normalizeUsername(item.username) === normalizedInput || 
    normalizeUsername(item.email) === normalizedInput ||
    normalizeUsername(item.username + item.email) === normalizedInput
  ) && users.find((item) => item.password === password);
  
  // Fallback: permitir login del administrador aunque no esté en localStorage
  if (!user && normalizeUsername(username) === 'roccoadmin67' && password === 'Roccopelado67') {
    return {
      user: {
        id: 'user_admin_rocco',
        name: 'Rocco Admin',
        username: 'Roccoadmin67',
        password: 'Roccopelado67',
        balance: 50000,
        profile: 'admin',
        portfolio: {},
        token: 'token_admin_rocco'
      },
      token: 'token_admin_rocco'
    };
  }
  
  if (!user) {
    throw new Error('Credenciales inválidas en modo local.');
  }
  return { user, token: user.token };
}

function formatCurrency(value) {
  return new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' }).format(value);
}

function showMessage(container, message, type = 'info') {
  const div = document.createElement('div');
  div.className = 'alert';
  div.textContent = message;
  if (type === 'error') div.style.borderColor = '#c15454';
  container.prepend(div);
  setTimeout(() => div.remove(), 5500);
}

function getQueryParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

async function fetchJson(url, options = {}) {
  try {
    const res = await fetch(url, options);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      const msg = data.error || res.statusText || 'Error en la solicitud';
      throw new Error(msg);
    }
    return await res.json();
  } catch (error) {
    const isNetworkError = error instanceof TypeError || (error.message && (error.message.includes('Failed to fetch') || error.message.includes('NetworkError')));
    
    if (url.startsWith(`${API_BASE}/products`)) {
      const productMatch = url.match(/\/products\/([^?\/]+)/);
      if (productMatch) {
        const productId = decodeURIComponent(productMatch[1]);
        const product = FALLBACK_PRODUCTS.find((item) => item.id === productId || item.symbol === productId);
        if (product) {
          return product;
        }
        if (isNetworkError) {
          throw new Error('Activo no encontrado en el modo local.');
        }
      }
      if (isNetworkError) {
        return { products: FALLBACK_PRODUCTS.map((item) => ({ ...item, risk: getProductRisk(item) })), total: FALLBACK_PRODUCTS.length };
      }
    }
    
    throw error;
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function fetchJsonWithRetry(url, options = {}, retries = 2, delay = 400) {
  try {
    return await fetchJson(url, options);
  } catch (error) {
    if (retries > 0) {
      await sleep(delay);
      return fetchJsonWithRetry(url, options, retries - 1, delay);
    }
    throw error;
  }
}

async function refreshCurrentUser() {
  const token = getStoredToken();
  if (!token) return getStoredUser();
  try {
    const user = await fetchJsonWithRetry(`${API_BASE}/auth/me`, { headers: authHeaders() });
    saveUser(user, token);
    return user;
  } catch {
    return getStoredUser();
  }
}

async function fetchQuotes(symbols) {
  if (!symbols || !symbols.length) return { quotes: [] };
  const query = symbols.map(encodeURIComponent).join(',');
  try {
    return await fetchJsonWithRetry(`${API_BASE}/quotes?symbols=${query}`);
  } catch {
    return { quotes: [] };
  }
}

function renderQuoteMiniChart(change) {
  const value = Number(change) || 0;
  const width = Math.min(100, Math.max(6, 50 + value * 1.5));
  const color = value >= 0 ? '#7ED321' : '#FF6B6B';
  return `
    <div style="display:flex;align-items:center;gap:10px;margin:10px 0;font-size:0.9rem;">
      <div style="flex:1;height:8px;background:rgba(255,255,255,0.1);border-radius:999px;overflow:hidden;">
        <div style="width:${width}%;height:100%;background:${color};border-radius:999px;"></div>
      </div>
      <span style="font-weight:600;color:${color};">${value >= 0 ? '+' : ''}${value}%</span>
    </div>
  `;
}

function getProductRisk(product) {
  if (product.risk) return product.risk;
  const subCategory = String(product.subCategory || '').toLowerCase();
  const type = String(product.type || '').toLowerCase();
  if (['opciones', 'futuros'].includes(subCategory) || ['opción', 'opciones', 'futuro', 'futuros'].includes(type)) {
    return 'Alto';
  }
  if (['títulos públicos', 'cauciones', 'fondos comunes'].includes(subCategory) || ['título público', 'caución', 'fondo'].includes(type)) {
    return 'Bajo';
  }
  return 'Medio';
}

function setupHeader() {
  const brand = document.querySelector('#logo-link');
  if (brand) {
    brand.addEventListener('click', (event) => {
      event.preventDefault();
      window.location.href = 'index.html';
    });
  }
  updateNavigation();
}

function isAdminUser() {
  const user = getStoredUser();
  return user && user.username === 'Roccoadmin67' && user.profile === 'admin';
}

function updateNavigation() {
  const nav = document.querySelector('#header-nav');
  const user = getStoredUser();
  if (!nav) return;
  if (!user) {
    nav.innerHTML = `
      <button id="open-register" class="primary" style="padding:6px 12px; font-size:0.8rem;">Crear cuenta</button>
      <button id="open-login" style="padding:6px 12px; font-size:0.8rem;">Iniciar sesión</button>
    `;
    document.querySelector('#open-register')?.addEventListener('click', () => openModal('register-modal'));
    document.querySelector('#open-login')?.addEventListener('click', () => openModal('login-modal'));
    return;
  }
  const adminLink = isAdminUser() ? '<a href="admin.html" style="font-size:0.75rem;">Admin</a>' : '';
  // Mostrar username generado arriba a la derecha con avatar - al hacer click muestra cerrar sesión
  const displayUsername = user.username || '';
  nav.innerHTML = `
    <a href="dashboard.html" style="font-size:0.75rem;">Mi cuenta</a>
    <a href="investments.html" style="font-size:0.75rem;">Inversiones</a>
    <a href="rentabilidad.html" style="font-size:0.75rem;">Rentabilidad</a>
    <a href="history.html" style="font-size:0.75rem;">Historial</a>
    <a href="about.html" style="font-size:0.75rem;">Quiénes somos</a>
    ${adminLink}
    <div style="position:relative; display:inline-block; margin-left:10px;">
      <div id="user-avatar" style="cursor:pointer; width:28px; height:28px; border-radius:50%; background:linear-gradient(135deg, #667eea 0%, #764ba2 100%); display:flex; align-items:center; justify-content:center; font-weight:bold; color:#fff; font-size:0.7rem;">
        ${displayUsername.substring(0, 2).toUpperCase()}
      </div>
      <div id="user-menu" style="display:none; position:absolute; right:0; top:100%; margin-top:5px; background:#1a1a2e; border:1px solid rgba(255,255,255,0.1); border-radius:6px; padding:5px 0; min-width:120px; z-index:1000; box-shadow:0 4px 12px rgba(0,0,0,0.3);">
        <div style="padding:8px 12px; border-bottom:1px solid rgba(255,255,255,0.1); margin-bottom:5px;">
          <span style="font-size:0.75rem; color:rgba(255,255,255,0.8);">@${displayUsername}</span>
        </div>
        <button id="logout-btn" style="width:100%; padding:8px 12px; background:none; border:none; color:#ff6b6b; font-size:0.8rem; text-align:left; cursor:pointer;">Cerrar sesión</button>
      </div>
    </div>
  `;
  
  // Toggle menu on avatar click
  const avatar = document.querySelector('#user-avatar');
  const menu = document.querySelector('#user-menu');
  avatar?.addEventListener('click', (e) => {
    e.stopPropagation();
    menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
  });
  
  // Close menu when clicking outside
  document.addEventListener('click', () => {
    menu.style.display = 'none';
  });
  
  document.querySelector('#logout-btn')?.addEventListener('click', () => {
    clearSession();
    window.location.href = 'index.html';
  });
}

function openModal(id) {
  document.getElementById(id)?.classList.add('visible');
}

function closeModal(id) {
  document.getElementById(id)?.classList.remove('visible');
}

function attachModalClose() {
  document.querySelectorAll('.modal .close').forEach((button) => {
    button.addEventListener('click', () => closeModal(button.closest('.modal')?.id));
  });
  document.querySelectorAll('.modal').forEach((modal) => {
    modal.addEventListener('click', (event) => {
      if (event.target === modal) closeModal(modal.id);
    });
  });
}

async function loadHome() {
  const recommendedGrid = document.querySelector('#recommended-grid');
  const newGrid = document.querySelector('#new-grid');
  let allProducts = FALLBACK_PRODUCTS;
  try {
    const allData = await fetchJson(`${API_BASE}/products?page=1&limit=200`);
    allProducts = allData.products || allProducts;
  } catch (error) {
    console.warn('No se pudo cargar el backend, se usan inversiones locales de respaldo.', error);
  }

  // Función para randomizar y seleccionar N productos únicos
  const getRandomProducts = (products, count) => {
    const shuffled = [...products].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, count);
  };

  if (recommendedGrid && newGrid) {
    // Obtener 5 productos al azar para la primera columna
    const col1Products = getRandomProducts(allProducts, 5);
    // Obtener los ids de la primera columna
    const col1Ids = new Set(col1Products.map(p => p.id));
    // Obtener 5 productos al azar del resto
    const remainingProducts = allProducts.filter(p => !col1Ids.has(p.id));
    const col2Products = getRandomProducts(remainingProducts, 5);

    recommendedGrid.innerHTML = col1Products.map((item) => `
      <article class="card-item">
        <span class="badge">${item.subCategory}</span>
        <h3>${item.name}</h3>
        <p>${item.description}</p>
        <p><span class="highlight">${formatCurrency(item.price)}</span></p>
        <a class="button" href="product.html?id=${encodeURIComponent(item.id)}">Ver activo</a>
      </article>
    `).join('');

    newGrid.innerHTML = col2Products.map((item) => `
      <article class="card-item">
        <span class="badge">${item.subCategory}</span>
        <h3>${item.name}</h3>
        <p>${item.description}</p>
        <p><span class="highlight">${formatCurrency(item.price)}</span></p>
        <a class="button" href="product.html?id=${encodeURIComponent(item.id)}">Ver activo</a>
      </article>
    `).join('');
  }
}

function createPageButton(label, page, current) {
  const button = document.createElement('button');
  button.textContent = label;
  button.disabled = page < 1 || page === current;
  if (!button.disabled) {
    button.addEventListener('click', () => {
      window.location.href = `index.html?page=${page}`;
    });
  }
  return button;
}

async function loadProfilePage() {
  const user = getStoredUser();
  if (!user) {
    window.location.href = 'index.html';
    return;
  }
  if (user.profile && user.profile !== 'Conservador' && user.profile !== 'Moderado' && user.profile !== 'Agresivo') {
    window.location.href = 'dashboard.html';
    return;
  }
  document.querySelectorAll('.profile-card button').forEach((button) => {
    button.addEventListener('click', async () => {
      const profileName = button.dataset.profile;
      user.profile = profileName;
      saveUser(user, getStoredToken());
      try {
        await fetchJson(`${API_BASE}/auth/profile`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...authHeaders()
          },
          body: JSON.stringify({ profile: profileName })
        }).catch(() => true);
      } catch (error) {
        console.log('Backend no disponible, se guarda localmente');
      }
      setTimeout(() => window.location.href = 'dashboard.html', 300);
    });
  });
}

async function loadDashboard() {
  const user = getStoredUser();
  if (!user) {
    window.location.href = 'index.html';
    return;
  }
  const nameEl = document.querySelector('#dashboard-name');
  const profileEl = document.querySelector('#dashboard-profile');
  const balanceEl = document.querySelector('#dashboard-balance');
  
  nameEl.textContent = `Hola, ${user.name}`;
  profileEl.textContent = user.profile || 'No definido';
  balanceEl.textContent = formatCurrency(user.balance || 0);
  
  document.querySelector('#form-balance').addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const type = form.querySelector('select[name="type"]').value;
    const amount = Number(form.querySelector('input[name="amount"]').value);
    
    if (amount <= 0 || amount > 50000000) {
      return showMessage(form, 'Monto inválido (máx. 50.000.000)', 'error');
    }
    
    const updatedUser = getStoredUser();
    if (type === 'deposit') {
      updatedUser.balance = (updatedUser.balance || 0) + amount;
      addHistoryEntry('deposit', amount);
    } else {
      if (updatedUser.balance < amount) {
        return showMessage(form, 'Fondos insuficientes', 'error');
      }
      updatedUser.balance -= amount;
      addHistoryEntry('withdraw', amount);
    }
    
    saveUser(updatedUser, getStoredToken());
    balanceEl.textContent = formatCurrency(updatedUser.balance);
    
    const msg = `${type === 'deposit' ? 'Depósito' : 'Retiro'} de ${formatCurrency(amount)} realizado con éxito.`;
    showMessage(form, msg, 'info');
    form.reset();
  });
}

function getProfileFilters(profile) {
  // Esta función ahora obtiene los filtros desde la API
  // Se mantiene como fallback por si la API no está disponible
  const fallbackFilters = {
    'Conservador': ['Fondos Comunes', 'Acciones', 'CEDEARs'],
    'Moderado': ['CEDEARs', 'Fondos Comunes', 'Acciones'],
    'Agresivo': ['Acciones', 'CEDEARs', 'Fondos Comunes']
  };
  return fallbackFilters[profile] || [];
}

function updateQuotesInUI(quoteMap) {
  document.querySelectorAll('.quote-chart').forEach((el) => {
    const symbol = el.dataset.symbol;
    const quote = quoteMap[symbol];
    if (quote) {
      el.innerHTML = renderQuoteMiniChart(quote.change);
    }
  });
}

async function loadInvestments() {
  const user = await refreshCurrentUser();
  if (!user) {
    window.location.href = 'index.html';
    return;
  }
  if (!user.profile) {
    window.location.href = 'profile.html';
    return;
  }
  const section = document.querySelector('#investments-list');
  if (!section) return;

  // Perfiles predefinidos
  const defaultProfiles = {
    'Conservador': { name: 'Conservador', riskLevel: 'Bajo', description: 'Perfil con bajo riesgo' },
    'Moderado': { name: 'Moderado', riskLevel: 'Medio', description: 'Perfil con riesgo medio' },
    'Agresivo': { name: 'Agresivo', riskLevel: 'Alto', description: 'Perfil con alto riesgo' }
  };
  const profileConfig = defaultProfiles;

  // Obtener productos y ordenarlos según el perfil de inversor
  const allProducts = getAllProducts();
  const normalizedProducts = (allProducts || []).map((item) => ({ ...item, risk: getProductRisk(item) }));
  
  // Función para ordenar productos según perfil de inversor
  const sortByProfile = (products, investorProfile) => {
    const profileMap = {
      'conservador': 'Bajo',
      'moderado': 'Medio',
      'agresivo': 'Alto'
    };
    
    const preferredRisk = profileMap[investorProfile?.toLowerCase()] || 'Medio';
    
    return products.sort((a, b) => {
      // Primero, los que coinciden con el perfil
      const aMatches = a.risk === preferredRisk ? 0 : 1;
      const bMatches = b.risk === preferredRisk ? 0 : 1;
      if (aMatches !== bMatches) return aMatches - bMatches;
      // Luego, ordenar alfabéticamente
      return a.name.localeCompare(b.name);
    });
  };
  
  // Ordenar productos según el investorProfile del usuario
  const sortedProducts = sortByProfile(normalizedProducts, user.investorProfile);

  // Obtener quotes de forma async
  let quoteMap = {};
  const quoteSymbols = [...new Set(sortedProducts.map((item) => item.symbol || item.id).filter(Boolean))];
  
  Promise.race([
    fetchQuotes(quoteSymbols),
    new Promise((_, reject) => setTimeout(() => reject('timeout'), 200))
  ]).then((quoteResponse) => {
    quoteMap = (quoteResponse.quotes || []).reduce((acc, quote) => {
      acc[quote.symbol] = quote;
      return acc;
    }, {});
    updateQuotesInUI(quoteMap);
  }).catch(() => {
    console.log('Quotes no disponibles');
  });

  let profileInfo = '';
  if (profileConfig && profileConfig[user.profile]) {
    const profile = profileConfig[user.profile];
    profileInfo = `
      <section class="card">
        <h2>Tu Perfil: ${profile.name}</h2>
        <p><strong>Nivel de Riesgo:</strong> ${profile.riskLevel}</p>
        <p>${profile.description}</p>
      </section>
    `;
  }

  const renderSection = (title, items) => `
    <section class="card">
      <h3>${title}</h3>
      <div class="grid-2">
        ${items.map((item) => {
          const quote = quoteMap[item.symbol] || {};
          return `
            <article class="card-item" data-product-id="${item.id}">
              <span class="badge">Riesgo: ${item.risk}</span>
              <span class="badge">${item.type || item.subCategory}</span>
              <h3>${item.name}</h3>
              <p>${item.description}</p>
              <div class="quote-chart" data-symbol="${item.symbol || item.id}">${renderQuoteMiniChart(quote.change)}</div>
              <div>
                <span class="highlight">${formatCurrency(item.price)}</span>
              </div>
              <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:12px;">
                <a class="button" href="product.html?id=${encodeURIComponent(item.id)}">Ver activo</a>
              </div>
            </article>
          `;
        }).join('')}
      </div>
    </section>
  `;

  const sections = [];
  sections.push(renderSection('Inversiones disponibles', sortedProducts));

  if (!sections.length) {
    section.innerHTML = `${profileInfo}<section class="card"><p>No hay inversiones disponibles.</p></section>`;
    return;
  }

  section.innerHTML = profileInfo + sections.join('');
}

async function loadHistory() {
  const user = getStoredUser();
  if (!user) {
    window.location.href = 'index.html';
    return;
  }
  const table = document.querySelector('#history-list');
  if (!table) return;
  
  let history = getLocalHistory().filter((trx) => trx.userId === user.id);
  
  try {
    const response = await fetchJson(`${API_BASE}/history`, { headers: authHeaders() });
    if (response.history && Array.isArray(response.history)) {
      history = [...history, ...response.history];
    }
  } catch (error) {
    console.log('Usando historial local');
  }
  
  if (!history.length) {
    table.innerHTML = '<p style="grid-column: 1 / -1;">No hay movimientos registrados todavía.</p>';
    return;
  }
  
  history = history.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  table.innerHTML = history.map((trx) => {
    let icon = '💱';
    if (trx.type === 'deposit') icon = '📥';
    else if (trx.type === 'withdraw') icon = '📤';
    else if (trx.type === 'buy') icon = trx.status === 'failed' ? '❌' : '✅';
    else if (trx.type === 'sell') icon = trx.status === 'failed' ? '❌' : '✅';
    
    const typeLabel = trx.type === 'deposit' ? 'Depósito' : trx.type === 'withdraw' ? 'Retiro' : trx.type === 'buy' ? `Compra - ${trx.assetName}` : trx.type === 'sell' ? `Venta - ${trx.assetName}` : `${trx.type} - ${trx.assetName}`;
    
    return `
      <article class="card-item">
        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px;">
          <span style="font-size: 1.5rem;">${icon}</span>
          <h3 style="margin: 0;">${typeLabel}</h3>
        </div>
        <p style="margin: 8px 0; color: rgba(255, 255, 255, 0.8);">Monto: <strong>${formatCurrency(trx.amount)}</strong></p>
        ${trx.quantity ? `<p style="margin: 8px 0; color: rgba(255, 255, 255, 0.8);">Cantidad: <strong>${trx.quantity}</strong></p>` : ''}
        <p style="margin: 8px 0; color: var(--accent);">Saldo: ${formatCurrency(trx.balanceAfter)}</p>
        <small style="color: rgba(255, 255, 255, 0.6);">${new Date(trx.date).toLocaleString('es-AR')}</small>
      </article>
    `;
  }).join('');
}

async function loadProductDetail() {
  const user = await refreshCurrentUser();
  if (!user) {
    window.location.href = 'index.html';
    return;
  }
  const productId = getQueryParam('id');
  const container = document.querySelector('#product-detail');
  if (!productId || !container) return;
  try {
    const product = await fetchJson(`${API_BASE}/products/${encodeURIComponent(productId)}`);
    const quote = (await fetchQuotes([product.symbol || product.id])).quotes[0] || {};
    container.innerHTML = `
      <div class="card-item">
        <span class="badge">${product.category} / ${product.subCategory}</span>
        <h3>${product.name}</h3>
        <p>${product.details}</p>
        ${renderQuoteMiniChart(quote.change)}
        <p><strong>Precio actual:</strong> ${formatCurrency(product.price)}</p>
        <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:14px;">
          <button id="buy-asset" class="button">Comprar</button>
          <button id="sell-asset" class="button">Vender</button>
          <a class="button" href="investments.html">Volver a inversiones</a>
        </div>
      </div>
    `;
    document.querySelector('#buy-asset')?.addEventListener('click', async () => {
      const quantity = Number(prompt('Ingrese la cantidad a comprar'));
      if (!quantity || quantity <= 0) return showMessage(container, 'Cantidad inválida', 'error');
      try {
        let result;
        try {
          result = await fetchJson(`${API_BASE}/trade`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...authHeaders() },
            body: JSON.stringify({ assetId: product.id, quantity, action: 'buy' })
          });
        } catch (apiError) {
          result = processLocalTrade(product.id, quantity, 'buy');
        }
        const updatedUser = getStoredUser();
        updatedUser.balance = result.balance;
        updatedUser.portfolio = result.portfolio || updatedUser.portfolio;
        saveUser(updatedUser, getStoredToken());
        addHistoryEntry('buy', quantity * product.price, product.name, quantity, product.id);
        showMessage(container, `Compra exitosa. Nuevo saldo: ${formatCurrency(result.balance)}`);
      } catch (error) {
        addHistoryEntry('buy', quantity * product.price, product.name, quantity, product.id, 'failed');
        showMessage(container, error.message, 'error');
      }
    });
    document.querySelector('#sell-asset')?.addEventListener('click', async () => {
      const quantity = Number(prompt('Ingrese la cantidad a vender'));
      if (!quantity || quantity <= 0) return showMessage(container, 'Cantidad inválida', 'error');
      try {
        let result;
        try {
          result = await fetchJson(`${API_BASE}/trade`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...authHeaders() },
            body: JSON.stringify({ assetId: product.id, quantity, action: 'sell' })
          });
        } catch (apiError) {
          result = processLocalTrade(product.id, quantity, 'sell');
        }
        const updatedUser = getStoredUser();
        updatedUser.balance = result.balance;
        updatedUser.portfolio = result.portfolio || updatedUser.portfolio;
        saveUser(updatedUser, getStoredToken());
        addHistoryEntry('sell', quantity * product.price, product.name, quantity, product.id);
        showMessage(container, `Venta realizada. Nuevo saldo: ${formatCurrency(result.balance)}`);
      } catch (error) {
        addHistoryEntry('sell', quantity * product.price, product.name, quantity, product.id, 'failed');
        showMessage(container, error.message, 'error');
      }
    });
  } catch (error) {
    container.innerHTML = `<div class="alert">${error.message}</div>`;
  }
}

function buildPortfolioCostBasis(transactions, products) {
  const lots = {};
  const nameToId = products.reduce((acc, product) => {
    acc[product.name] = product.id;
    acc[product.symbol] = product.id;
    return acc;
  }, {});
  const sorted = [...transactions].sort((a, b) => new Date(a.date) - new Date(b.date));

  sorted.forEach((trx) => {
    const assetId = trx.assetId || nameToId[trx.assetName] || null;
    const qty = Number(trx.quantity) || 0;
    const amount = Number(trx.amount) || 0;
    if (!assetId || qty <= 0 || amount <= 0) return;
    lots[assetId] = lots[assetId] || [];
    const type = String(trx.type || '').toLowerCase();
    if (type.includes('compra') || type === 'buy') {
      lots[assetId].push({ qty, amount });
      return;
    }
    if (type.includes('venta') || type === 'sell') {
      let remaining = qty;
      while (remaining > 0 && lots[assetId].length > 0) {
        const lot = lots[assetId][0];
        if (lot.qty <= remaining) {
          remaining -= lot.qty;
          lots[assetId].shift();
        } else {
          const ratio = remaining / lot.qty;
          lot.amount = lot.amount * (1 - ratio);
          lot.qty -= remaining;
          remaining = 0;
        }
      }
    }
  });

  return Object.fromEntries(Object.entries(lots).map(([id, assetLots]) => [
    id,
    {
      totalQty: assetLots.reduce((sum, lot) => sum + lot.qty, 0),
      costBasis: assetLots.reduce((sum, lot) => sum + lot.amount, 0)
    }
  ]));
}

async function loadRentability() {
  const user = await refreshCurrentUser();
  if (!user) {
    window.location.href = 'index.html';
    return;
  }
  const container = document.querySelector('#rentability-list');
  if (!container) return;

  const portfolio = user.portfolio || {};
  if (!portfolio || !Object.keys(portfolio).length) {
    container.innerHTML = '<section class="card"><p>No tenés posiciones abiertas aún. Comprá activos para ver tu rentabilidad.</p></section>';
    return;
  }

  const allProductsResponse = await fetchJsonWithRetry(`${API_BASE}/products?page=1&limit=200`).catch(() => ({ products: FALLBACK_PRODUCTS }));
  const allProducts = allProductsResponse.products || FALLBACK_PRODUCTS;

  let history = getLocalHistory().filter((trx) => trx.userId === user.id);
  try {
    const response = await fetchJson(`${API_BASE}/history`, { headers: authHeaders() });
    if (response.history && Array.isArray(response.history)) {
      history = [...history, ...response.history];
    }
  } catch {
    console.log('No se pudo obtener historial del servidor para rentabilidad');
  }

  const seen = new Set();
  history = history.filter((trx) => {
    if (!trx.id) return true;
    if (seen.has(trx.id)) return false;
    seen.add(trx.id);
    return true;
  });

  const costBasisMap = buildPortfolioCostBasis(history, allProducts);
  const holdings = Object.entries(portfolio)
    .filter(([assetId, qty]) => Number(qty) > 0)
    .map(([assetId, quantity]) => {
      const product = allProducts.find((item) => item.id === assetId || item.symbol === assetId);
      const quote = product ? (product.symbol ? (product.symbol) : assetId) : assetId;
      return {
        assetId,
        quantity: Number(quantity),
        product,
        costBasis: costBasisMap[assetId]?.costBasis || 0,
        averageCost: costBasisMap[assetId]?.totalQty ? costBasisMap[assetId].costBasis / costBasisMap[assetId].totalQty : 0
      };
    })
    .filter((item) => item.product);

  if (!holdings.length) {
    container.innerHTML = '<section class="card"><p>No se encontraron activos válidos en tu cartera para calcular rentabilidad.</p></section>';
    return;
  }

  const quoteSymbols = [...new Set(holdings.map((item) => item.product.symbol || item.assetId))];
  const quoteResponse = await fetchQuotes(quoteSymbols);
  const quoteMap = (quoteResponse.quotes || []).reduce((acc, quote) => {
    acc[quote.symbol] = quote;
    return acc;
  }, {});

  let totalCost = 0;
  let totalCurrent = 0;
  const rows = holdings.map((holding) => {
    const quote = quoteMap[holding.product.symbol] || {};
    const currentPrice = Number(quote.price || holding.product.price || 0);
    const currentValue = currentPrice * holding.quantity;
    const costBasis = holding.costBasis || holding.averageCost * holding.quantity || 0;
    const diff = currentValue - costBasis;
    totalCost += costBasis;
    totalCurrent += currentValue;
    const diffLabel = costBasis ? `${diff >= 0 ? '+' : ''}${formatCurrency(diff)}` : 'Sin historial de compras';
    const diffPercent = costBasis ? `${diff >= 0 ? '+' : ''}${((diff / costBasis) * 100).toFixed(2)}%` : '--';

    return `
      <article class="card-item">
        <span class="badge">${holding.product.subCategory} · ${holding.product.type}</span>
        <h3>${holding.product.name}</h3>
        <p>Cantidad: <strong>${holding.quantity}</strong></p>
        <p>Valor actual: <strong>${formatCurrency(currentValue)}</strong></p>
        <p>Costo histórico: <strong>${costBasis ? formatCurrency(costBasis) : 'No disponible'}</strong></p>
        <p>${renderQuoteMiniChart(quote.change)}</p>
        <p><strong>Rentabilidad:</strong> ${diffLabel} (${diffPercent})</p>
      </article>
    `;
  });

  const overallDiff = totalCurrent - totalCost;
  const overallPercent = totalCost ? `${overallDiff >= 0 ? '+' : ''}${((overallDiff / totalCost) * 100).toFixed(2)}%` : '--';
  container.innerHTML = `
    <section class="card">
      <h2>Rentabilidad total</h2>
      <p><strong>Valor actual de cartera:</strong> ${formatCurrency(totalCurrent)}</p>
      <p><strong>Costo total histórico:</strong> ${totalCost ? formatCurrency(totalCost) : 'No disponible'}</p>
      <p><strong>Rentabilidad:</strong> ${overallDiff >= 0 ? '+' : ''}${formatCurrency(overallDiff)} (${overallPercent})</p>
    </section>
    <section class="grid-2">
      ${rows.join('')}
    </section>
  `;
}

async function loadAdmin() {
  const user = await refreshCurrentUser();
  if (!user) {
    window.location.href = 'index.html';
    return;
  }
  if (!isAdminUser()) {
    window.location.href = 'dashboard.html';
    return;
  }
  const form = document.querySelector('#admin-form');
  const list = document.querySelector('#admin-list');
  if (!form || !list) return;

  const fillForm = (product) => {
    form.productId.value = product.id;
    form.name.value = product.name;
    form.symbol.value = product.symbol;
    form.type.value = product.type || '';
    form.price.value = product.price;
    form.image.value = product.image || '';
    form.category.value = product.category;
    form.subCategory.value = product.subCategory;
    form.featured.value = product.featured || 'general';
    form.description.value = product.description;
    form.details.value = product.details || '';
    form.querySelector('button[type="submit"]').textContent = 'Guardar cambios';
  };

  const clearForm = () => {
    form.productId.value = '';
    form.reset();
    form.querySelector('button[type="submit"]').textContent = 'Agregar producto';
  };

  const reloadProducts = async () => {
    const data = await fetchJson(`${API_BASE}/products?page=1&limit=200`);
    list.innerHTML = data.products.map((product) => `
      <article class="card-item">
        <h3>${product.name}</h3>
        <p>${product.description}</p>
        <small>${product.category} / ${product.subCategory} · Riesgo: ${product.risk || getProductRisk(product)}</small>
        <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:14px;">
          <button class="button" type="button" data-id="${product.id}" data-action="edit">Editar</button>
          <button class="button danger" type="button" data-id="${product.id}" data-action="delete">Eliminar</button>
        </div>
      </article>
    `).join('');

    list.querySelectorAll('button[data-id]').forEach((button) => {
      button.addEventListener('click', async () => {
        const productId = button.dataset.id;
        const action = button.dataset.action;
        if (action === 'edit') {
          const product = data.products.find((item) => item.id === productId);
          if (product) {
            fillForm(product);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }
        } else if (action === 'delete') {
          if (confirm('¿Estás seguro de que quieres eliminar este producto?')) {
            try {
              await fetchJson(`${API_BASE}/admin/products/${encodeURIComponent(productId)}`, {
                method: 'DELETE',
                headers: authHeaders()
              });
              showMessage(list, 'Producto eliminado correctamente');
              await reloadProducts();
            } catch (error) {
              showMessage(list, error.message, 'error');
            }
          }
        }
      });
    });
  };

  await reloadProducts();
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const payload = {
      name: form.name.value.trim(),
      description: form.description.value.trim(),
      details: form.details.value.trim(),
      category: form.category.value,
      subCategory: form.subCategory.value,
      type: form.type.value.trim(),
      price: Number(form.price.value),
      featured: form.featured.value,
      image: form.image.value || 'assets/images/product-placeholder.svg',
      symbol: form.symbol.value.trim() || form.name.value.trim()
    };
    const productId = form.productId.value.trim();
    try {
      if (productId) {
        await fetchJson(`${API_BASE}/admin/products/${encodeURIComponent(productId)}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json', ...authHeaders() },
          body: JSON.stringify(payload)
        });
        showMessage(form, 'Producto actualizado correctamente');
      } else {
        await fetchJson(`${API_BASE}/admin/products`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...authHeaders() },
          body: JSON.stringify(payload)
        });
        showMessage(form, 'Producto agregado correctamente');
      }
      clearForm();
      await reloadProducts();
    } catch (error) {
      showMessage(form, error.message, 'error');
    }
  });
}

async function loadAuthForms() {
  const registerForm = document.querySelector('#register-form');
  const loginForm = document.querySelector('#login-form');
  
  if (registerForm) {
    registerForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const name = registerForm.querySelector('input[name="name"]')?.value.trim();
      const lastname = registerForm.querySelector('input[name="lastname"]')?.value.trim();
      const email = registerForm.querySelector('input[name="email"]')?.value.trim();
      const password = registerForm.querySelector('input[name="password"]')?.value;
      const investorProfile = registerForm.querySelector('select[name="investorProfile"]')?.value;
      
      if (!name || !lastname || !email || !password || !investorProfile) {
        return showMessage(registerForm, 'Completa todos los campos.', 'error');
      }
      if (password.length < 8 || !/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
        return showMessage(registerForm, 'La contraseña debe tener al menos 8 caracteres y un símbolo especial.', 'error');
      }
      
      const payload = { name, lastname, email, password, investorProfile };
      let registered = false;
      
      try {
        const result = await fetchJson(`${API_BASE}/auth/register`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        saveUser(result.user, result.token);
        registered = true;
      } catch (error) {
        try {
          const result = createLocalUser(payload);
          saveUser(result.user, result.token);
          registered = true;
        } catch (localError) {
          return showMessage(registerForm, localError.message || error.message, 'error');
        }
      }
      
      if (registered) {
        closeModal('register-modal');
        registerForm.reset();
        window.location.href = 'dashboard.html';
      }
    });
  }
  
  if (loginForm) {
    loginForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const username = loginForm.username.value.trim();
      const password = loginForm.password.value;
      
      if (!username || !password) {
        return showMessage(loginForm, 'Completa usuario y contraseña.', 'error');
      }
      
      // Permitir login con usuario o correo electrónico
      const payload = { username, password };
      let loggedIn = false;
      let user = null;
      
      try {
        const result = await fetchJson(`${API_BASE}/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        saveUser(result.user, result.token);
        user = result.user;
        loggedIn = true;
      } catch (error) {
        try {
          const result = loginLocal(payload);
          saveUser(result.user, result.token);
          user = result.user;
          loggedIn = true;
        } catch (localError) {
          return showMessage(loginForm, localError.message || error.message, 'error');
        }
      }
      
      if (loggedIn && user) {
        closeModal('login-modal');
        loginForm.reset();
        window.location.href = user.profile === 'admin' ? 'admin.html' : (user.profile ? 'dashboard.html' : 'profile.html');
      }
    });
  }
}

function initPage() {
  setupHeader();
  attachModalClose();
  loadAuthForms();
  const page = document.body.dataset.page;
  if (page === 'home') {
    loadHome();
  }
  if (page === 'profile') {
    loadProfilePage();
  }
  if (page === 'dashboard') {
    loadDashboard();
  }
  if (page === 'investments') {
    loadInvestments();
  }
  if (page === 'history') {
    loadHistory();
  }
  if (page === 'product' && !window.productPageLoaded) {
    loadProductDetail();
  }
  if (page === 'admin') {
    loadAdmin();
  }
  if (page === 'rentabilidad') {
    loadRentability();
  }
}

window.addEventListener('DOMContentLoaded', initPage);
