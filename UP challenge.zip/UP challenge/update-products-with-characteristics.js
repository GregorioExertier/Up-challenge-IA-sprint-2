#!/usr/bin/env node
/**
 * Script para actualizar productos existentes con características iniciales
 * Uso: node update-products-with-characteristics.js
 */

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const PRODUCTS_FILE = path.join(DATA_DIR, 'products.json');

// Mapeo de características por tipo de producto
const CHARACTERISTICS_MAP = {
  // Acciones argentinas - Riesgo Medio, Argentina, Renta Variable
  'YPF': ['char_risk_medio', 'char_country_ar', 'char_type_rentavariable', 'char_type_acciones'],
  'GGAL': ['char_risk_medio', 'char_country_ar', 'char_type_rentavariable', 'char_type_acciones'],
  'PAMP': ['char_risk_bajo', 'char_country_ar', 'char_type_rentavariable', 'char_type_acciones'],
  'TXAR': ['char_risk_alto', 'char_country_ar', 'char_type_rentavariable', 'char_type_acciones'],
  'BBAR': ['char_risk_medio', 'char_country_ar', 'char_type_rentavariable', 'char_type_acciones'],
  'SUPV': ['char_risk_medio', 'char_country_ar', 'char_type_rentavariable', 'char_type_acciones'],
  'COME': ['char_risk_bajo', 'char_country_ar', 'char_type_rentavariable', 'char_type_acciones'],

  // CEDEARs - Riesgo Alto/Medio, Global/USA, Renta Variable
  'AAPL': ['char_risk_alto', 'char_country_usa', 'char_type_rentavariable', 'char_type_cedear'],
  'TSLA': ['char_risk_alto', 'char_country_usa', 'char_type_rentavariable', 'char_type_cedear'],
  'SPY': ['char_risk_medio', 'char_country_global', 'char_type_rentavariable', 'char_type_cedear'],
  'KO': ['char_risk_bajo', 'char_country_usa', 'char_type_rentavariable', 'char_type_cedear'],
  'MSFT': ['char_risk_alto', 'char_country_usa', 'char_type_rentavariable', 'char_type_cedear'],
  'NVDA': ['char_risk_alto', 'char_country_usa', 'char_type_rentavariable', 'char_type_cedear'],
  'AMZN': ['char_risk_alto', 'char_country_usa', 'char_type_rentavariable', 'char_type_cedear'],
  'META': ['char_risk_alto', 'char_country_usa', 'char_type_rentavariable', 'char_type_cedear'],

  // Títulos Públicos - Riesgo Bajo, Argentina, Renta Fija
  'AL29': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
  'AL30': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
  'AL35': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
  'GD29': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
  'GD30': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
  'GD35': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
  'T2X4': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
  'TX26': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
  'TX28': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
  'TO26': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
  'TO28': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
  'TDA24': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
  'TDG26': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],

  // Obligaciones Negociables - Riesgo Medio, Argentina, Renta Fija
  'YPFON2030': ['char_risk_medio', 'char_country_ar', 'char_type_rentafija'],
  'PAMPON': ['char_risk_medio', 'char_country_ar', 'char_type_rentafija'],
  'IRSAON': ['char_risk_medio', 'char_country_ar', 'char_type_rentafija'],
  'VISTAENERGYBOND': ['char_risk_medio', 'char_country_ar', 'char_type_rentafija'],
  'TELECOMBOND': ['char_risk_medio', 'char_country_ar', 'char_type_rentafija'],

  // Cauciones - Riesgo Bajo, Argentina, Renta Fija
  'CAU1D': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
  'CAU7D': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
  'CAU30D': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],
  'CAU90D': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija'],

  // Opciones - Riesgo Alto, Argentina, Derivados
  'CALLPAMP': ['char_risk_alto', 'char_country_ar', 'char_type_opciones'],
  'PUTYPF': ['char_risk_alto', 'char_country_ar', 'char_type_opciones'],
  'CALLYPF': ['char_risk_alto', 'char_country_ar', 'char_type_opciones'],
  'PUTGGAL': ['char_risk_alto', 'char_country_ar', 'char_type_opciones'],

  // Futuros - Riesgo Alto, Argentina, Derivados
  'DLR0626': ['char_risk_alto', 'char_country_ar', 'char_type_futuros'],
  'IMV0626': ['char_risk_alto', 'char_country_ar', 'char_type_futuros'],
  'SOJ0726': ['char_risk_alto', 'char_country_ar', 'char_type_futuros'],

  // Fondos Comunes - Variable
  'FMMG': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija', 'char_type_fondos'],
  'FRFBBVA': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija', 'char_type_fondos'],
  'FCER': ['char_risk_bajo', 'char_country_ar', 'char_type_rentafija', 'char_type_fondos'],
  'FDLD': ['char_risk_bajo', 'char_country_global', 'char_type_rentafija', 'char_type_fondos'],
  'FACC': ['char_risk_medio', 'char_country_ar', 'char_type_rentavariable', 'char_type_fondos'],
  'FGLO': ['char_risk_medio', 'char_country_global', 'char_type_rentavariable', 'char_type_fondos'],
};

function updateProducts() {
  try {
    // Leer productos existentes
    const productsData = fs.readFileSync(PRODUCTS_FILE, 'utf8');
    const products = JSON.parse(productsData);

    let updated = 0;
    products.forEach((product) => {
      // Si el producto no tiene características, asignarlas
      if (!product.characteristics) {
        const characteristics = CHARACTERISTICS_MAP[product.id] || [];
        if (characteristics.length > 0) {
          product.characteristics = characteristics;
          updated++;
        }
      }
    });

    // Guardar cambios
    fs.writeFileSync(PRODUCTS_FILE, JSON.stringify(products, null, 2), 'utf8');

    console.log(`✅ Actualización completada`);
    console.log(`   ${updated} productos actualizados con características`);
  } catch (error) {
    console.error('❌ Error al actualizar productos:', error.message);
    process.exit(1);
  }
}

// Ejecutar si se llama directamente
if (require.main === module) {
  updateProducts();
}

module.exports = updateProducts;
