const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const PRODUCTS_FILE = path.join(DATA_DIR, 'products.json');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const TRANSACTIONS_FILE = path.join(DATA_DIR, 'transactions.json');
const BYMA_SCRAPE_FILE = path.join(DATA_DIR, 'byma_scrape.json');
const PROFILES_FILE = path.join(DATA_DIR, 'profiles.json');
const CHARACTERISTICS_FILE = path.join(DATA_DIR, 'characteristics.json');

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/assets', express.static(path.join(__dirname, 'public', 'assets')));

function readJson(filename, defaultValue) {
  try {
    const data = fs.readFileSync(filename, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Error reading ${filename}:`, error.message);
    return defaultValue;
  }
}

function writeJson(filename, data) {
  fs.writeFileSync(filename, JSON.stringify(data, null, 2), 'utf8');
}

function ensureDataFiles() {
  if (!fs.existsSync(PRODUCTS_FILE)) writeJson(PRODUCTS_FILE, []);
  if (!fs.existsSync(USERS_FILE)) writeJson(USERS_FILE, []);
  if (!fs.existsSync(TRANSACTIONS_FILE)) writeJson(TRANSACTIONS_FILE, []);
  if (!fs.existsSync(BYMA_SCRAPE_FILE)) writeJson(BYMA_SCRAPE_FILE, { timestamp: null, symbolData: [] });
}

function generateId(prefix = 'id') {
  return `${prefix}_${Math.random().toString(36).substring(2, 10)}`;
}

function getProducts() {
  return readJson(PRODUCTS_FILE, []);
}

function getUsers() {
  return readJson(USERS_FILE, []);
}

function getTransactions() {
  return readJson(TRANSACTIONS_FILE, []);
}

function getProfiles() {
  return readJson(PROFILES_FILE, {});
}

function getCharacteristics() {
  return readJson(CHARACTERISTICS_FILE, []);
}

function determineProductRisk(product) {
  const subCategory = String(product.subCategory || '').toLowerCase();
  const type = String(product.type || '').toLowerCase();

  if (['opciones', 'futuros'].includes(subCategory) || ['opción', 'opciones', 'futuro', 'futuros'].includes(type)) {
    return 'Alto';
  }
  if (['títulos públicos', 'cauciones', 'fondos comunes'].includes(subCategory) || ['título público', 'caución', 'fondo'].includes(type)) {
    return 'Bajo';
  }
  return 'Medio';
}

function normalizeProduct(product) {
  return {
    ...product,
    risk: product.risk || determineProductRisk(product)
  };
}

function findUserByToken(token) {
  const users = getUsers();
  return users.find((user) => user.token === token);
}

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.replace('Bearer ', '');
  if (!token) {
    return res.status(401).json({ error: 'Token no provisto' });
  }
  const user = findUserByToken(token);
  if (!user) {
    return res.status(401).json({ error: 'Token inválido' });
  }
  req.user = user;
  next();
}

function adminMiddleware(req, res, next) {
  if (!req.user || req.user.profile !== 'admin') {
    return res.status(403).json({ error: 'Acceso administrativo requerido' });
  }
  next();
}

app.get('/api/products', (req, res) => {
  const { page = 1, limit = 10, random } = req.query;
  const all = getProducts().map(normalizeProduct);
  if (random === 'true') {
    const copy = [...all];
    const result = [];
    while (result.length < Math.min(10, copy.length)) {
      const index = Math.floor(Math.random() * copy.length);
      result.push(copy.splice(index, 1)[0]);
    }
    return res.json({ products: result, total: all.length });
  }
  const pageNum = Number(page);
  const limitNum = Number(limit);
  const start = (pageNum - 1) * limitNum;
  const paginated = all.slice(start, start + limitNum);
  res.json({ products: paginated, total: all.length });
});

app.get('/api/products/:id', (req, res) => {
  const all = getProducts();
  const product = all.find((item) => item.id === req.params.id);
  if (!product) return res.status(404).json({ error: 'Producto no encontrado' });
  res.json(normalizeProduct(product));
});

app.post('/api/admin/products', authMiddleware, adminMiddleware, (req, res) => {
  const { name, description, category, subCategory, price, featured, image, type, symbol, characteristics } = req.body;
  if (!name || !description || !category || !subCategory) {
    return res.status(400).json({ error: 'Faltan datos obligatorios' });
  }
  const products = getProducts();
  if (products.some((product) => product.id !== req.body.id && product.name.toLowerCase() === name.toLowerCase())) {
    return res.status(400).json({ error: 'El nombre ya está en uso' });
  }
  const newProduct = {
    id: generateId('prod'),
    name,
    description,
    category,
    subCategory,
    type: type || 'Activo',
    price: Number(price) || 1,
    featured: featured || 'general',
    image: image || 'assets/images/product-placeholder.svg',
    details: req.body.details || 'Producto de inversión creado en el panel administrativo.',
    history: [],
    symbol: symbol || name,
    risk: determineProductRisk({ category, subCategory, type }),
    characteristics: Array.isArray(characteristics) ? characteristics : []
  };
  products.push(newProduct);
  writeJson(PRODUCTS_FILE, products);
  res.json({ message: 'Producto agregado correctamente', product: newProduct });
});

app.put('/api/admin/products/:id', authMiddleware, adminMiddleware, (req, res) => {
  const { name, description, category, subCategory, price, featured, image, details, symbol, type, risk, characteristics } = req.body;
  const products = getProducts();
  const index = products.findIndex((product) => product.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Producto no encontrado' });
  }
  const duplicate = products.find((product) => product.id !== req.params.id && product.name.toLowerCase() === name.toLowerCase());
  if (duplicate) {
    return res.status(400).json({ error: 'El nombre ya está en uso por otro producto' });
  }
  const updatedProduct = {
    ...products[index],
    name: name || products[index].name,
    description: description || products[index].description,
    category: category || products[index].category,
    subCategory: subCategory || products[index].subCategory,
    type: type || products[index].type,
    price: Number(price) || products[index].price,
    featured: featured || products[index].featured,
    image: image || products[index].image,
    details: details || products[index].details,
    symbol: symbol || products[index].symbol,
    risk: risk || determineProductRisk({ category: category || products[index].category, subCategory: subCategory || products[index].subCategory, type: type || products[index].type }),
    characteristics: Array.isArray(characteristics) ? characteristics : (products[index].characteristics || [])
  };
  products[index] = updatedProduct;
  writeJson(PRODUCTS_FILE, products);
  res.json({ message: 'Producto actualizado correctamente', product: updatedProduct });
});

app.delete('/api/admin/products/:id', authMiddleware, adminMiddleware, (req, res) => {
  const products = getProducts();
  const index = products.findIndex((product) => product.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Producto no encontrado' });
  }
  const deletedProduct = products.splice(index, 1)[0];
  writeJson(PRODUCTS_FILE, products);
  res.json({ message: 'Producto eliminado correctamente', product: deletedProduct });
});

// Endpoint para obtener configuración de perfiles de inversor
app.get('/api/profiles', (req, res) => {
  const profiles = getProfiles();
  res.json(profiles);
});

app.post('/api/auth/register', (req, res) => {
  const { name, lastname, email, password, investorProfile } = req.body;
  if (!name || !lastname || !email || !password || !investorProfile) {
    return res.status(400).json({ error: 'Todos los campos son obligatorios' });
  }
  if (password.length < 8 || !/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
    return res.status(400).json({ error: 'La contraseña debe tener 8 o más caracteres y un símbolo especial' });
  }
  if (!['conservador', 'moderado', 'agresivo'].includes(investorProfile)) {
    return res.status(400).json({ error: 'Perfil inversor inválido' });
  }
  const users = getUsers();
  if (users.some((user) => user.email && user.email.toLowerCase() === email.toLowerCase())) {
    return res.status(400).json({ error: 'El correo electrónico ya está registrado' });
  }
  const token = generateId('token');
  const user = {
    id: generateId('user'),
    name: `${name} ${lastname}`,
    email,
    password,
    balance: 50000,
    investorProfile: investorProfile,
    profile: null,
    portfolio: {},
    token,
    createdAt: new Date().toISOString()
  };
  users.push(user);
  writeJson(USERS_FILE, users);
  res.json({ message: 'Usuario creado correctamente', user: { id: user.id, name: user.name, email: user.email, investorProfile: user.investorProfile, profile: user.profile, balance: user.balance }, token });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const users = getUsers();
  
  // Intentar con username primero (para admin)
  let user = users.find((item) => item.username && item.username.toLowerCase() === username.toLowerCase() && item.password === password);
  
  // Si no encuentra por username, intentar con email
  if (!user) {
    user = users.find((item) => item.email && item.email.toLowerCase() === username.toLowerCase() && item.password === password);
  }
  
  if (!user) {
    return res.status(401).json({ error: 'Credenciales inválidas' });
  }
  user.token = user.token || generateId('token');
  writeJson(USERS_FILE, users);
  const userResponse = { id: user.id, name: user.name, profile: user.profile, balance: user.balance, portfolio: user.portfolio };
  if (user.email) userResponse.email = user.email;
  if (user.investorProfile) userResponse.investorProfile = user.investorProfile;
  res.json({ message: 'Inicio de sesión exitoso', user: userResponse, token: user.token });
});

app.post('/api/auth/profile', authMiddleware, (req, res) => {
  const { profile } = req.body;
  if (!profile) {
    return res.status(400).json({ error: 'Debes seleccionar un perfil' });
  }
  const users = getUsers();
  const index = users.findIndex((item) => item.id === req.user.id);
  users[index].profile = profile;
  writeJson(USERS_FILE, users);
  res.json({ message: 'Perfil guardado', profile });
});

app.get('/api/auth/me', authMiddleware, (req, res) => {
  const { password, token, ...userData } = req.user;
  res.json(userData);
});

app.post('/api/balance', authMiddleware, (req, res) => {
  const { type, amount } = req.body;
  const amountNum = Number(amount);
  if (!['deposit', 'withdraw'].includes(type)) {
    return res.status(400).json({ error: 'Tipo de operación inválido' });
  }
  if (!amountNum || amountNum <= 0 || amountNum > 50000000) {
    return res.status(400).json({ error: 'El monto debe ser mayor a 0 y no superar 50 millones' });
  }
  const users = getUsers();
  const index = users.findIndex((item) => item.id === req.user.id);
  if (type === 'withdraw' && users[index].balance < amountNum) {
    return res.status(400).json({ error: 'Fondos insuficientes' });
  }
  users[index].balance += type === 'deposit' ? amountNum : -amountNum;
  writeJson(USERS_FILE, users);
  const transactions = getTransactions();
  transactions.unshift({
    id: generateId('trx'),
    userId: req.user.id,
    type: type === 'deposit' ? 'Depósito' : 'Retiro',
    amount: amountNum,
    assetName: type === 'deposit' ? 'Carga de capital' : 'Retiro de capital',
    date: new Date().toISOString(),
    balanceAfter: users[index].balance
  });
  writeJson(TRANSACTIONS_FILE, transactions);
  res.json({ message: 'Saldo actualizado', balance: users[index].balance });
});

app.post('/api/trade', authMiddleware, (req, res) => {
  const { assetId, quantity, action } = req.body;
  const quantityNum = Number(quantity);
  const products = getProducts();
  const product = products.find((item) => item.id === assetId);
  if (!product) {
    return res.status(400).json({ error: 'Activo no encontrado' });
  }
  if (!['buy', 'sell'].includes(action) || quantityNum <= 0) {
    return res.status(400).json({ error: 'Operación inválida' });
  }
  const price = Number(product.price);
  const cost = price * quantityNum;
  const users = getUsers();
  const index = users.findIndex((item) => item.id === req.user.id);
  const user = users[index];
  user.portfolio = user.portfolio || {};
  if (action === 'buy') {
    if (cost > user.balance) {
      return res.status(400).json({ error: 'Saldo insuficiente para la compra' });
    }
    user.balance -= cost;
    user.portfolio[assetId] = (user.portfolio[assetId] || 0) + quantityNum;
  } else {
    const owned = user.portfolio[assetId] || 0;
    if (quantityNum > owned) {
      return res.status(400).json({ error: 'No posees cantidad suficiente para vender' });
    }
    user.balance += cost;
    user.portfolio[assetId] = owned - quantityNum;
  }
  users[index] = user;
  writeJson(USERS_FILE, users);
  const transactions = getTransactions();
  transactions.unshift({
    id: generateId('trx'),
    userId: user.id,
    type: action === 'buy' ? 'Compra' : 'Venta',
    amount: cost,
    assetId: assetId,
    assetName: product.name,
    quantity: quantityNum,
    date: new Date().toISOString(),
    balanceAfter: user.balance
  });
  writeJson(TRANSACTIONS_FILE, transactions);
  
  // Devolver el usuario actualizado (sin contraseña)
  const { password, token, ...userResponse } = user;
  res.json({ message: 'Operación realizada', user: userResponse, balance: user.balance, portfolio: user.portfolio });
});

app.get('/api/history', authMiddleware, (req, res) => {
  const transactions = getTransactions().filter((trx) => trx.userId === req.user.id);
  res.json({ history: transactions });
});

app.get('/api/quotes', (req, res) => {
  const symbols = typeof req.query.symbols === 'string' ? req.query.symbols.split(',').map((sym) => sym.trim()) : [];
  const products = getProducts();
  const result = products
    .filter((product) => symbols.length === 0 || symbols.includes(product.symbol))
    .map((product) => ({
      symbol: product.symbol,
      price: Number(product.price),
      change: ((Math.random() - 0.45) * 4).toFixed(2)
    }));
  res.json({ quotes: result });
});

app.get('/api/byma-scrape', (req, res) => {
  const data = readJson(BYMA_SCRAPE_FILE, { timestamp: null, symbolData: [] });
  res.json(data);
});

// Endpoints de características
app.get('/api/characteristics', (req, res) => {
  const characteristics = getCharacteristics();
  res.json({ characteristics });
});

app.get('/api/admin/characteristics', authMiddleware, adminMiddleware, (req, res) => {
  const characteristics = getCharacteristics();
  res.json({ characteristics });
});

app.post('/api/admin/characteristics', authMiddleware, adminMiddleware, (req, res) => {
  const { name, icon, category, description } = req.body;
  if (!name || !icon || !category) {
    return res.status(400).json({ error: 'Faltan datos obligatorios (name, icon, category)' });
  }
  const characteristics = getCharacteristics();
  const newCharacteristic = {
    id: generateId('char'),
    name,
    icon,
    category,
    description: description || ''
  };
  characteristics.push(newCharacteristic);
  writeJson(CHARACTERISTICS_FILE, characteristics);
  res.json({ message: 'Característica agregada correctamente', characteristic: newCharacteristic });
});

app.put('/api/admin/characteristics/:id', authMiddleware, adminMiddleware, (req, res) => {
  const { name, icon, category, description } = req.body;
  const characteristics = getCharacteristics();
  const index = characteristics.findIndex((c) => c.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Característica no encontrada' });
  }
  const updatedCharacteristic = {
    ...characteristics[index],
    name: name || characteristics[index].name,
    icon: icon || characteristics[index].icon,
    category: category || characteristics[index].category,
    description: description !== undefined ? description : characteristics[index].description
  };
  characteristics[index] = updatedCharacteristic;
  writeJson(CHARACTERISTICS_FILE, characteristics);
  res.json({ message: 'Característica actualizada correctamente', characteristic: updatedCharacteristic });
});

app.delete('/api/admin/characteristics/:id', authMiddleware, adminMiddleware, (req, res) => {
  const characteristics = getCharacteristics();
  const index = characteristics.findIndex((c) => c.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Característica no encontrada' });
  }
  const deletedCharacteristic = characteristics.splice(index, 1)[0];
  writeJson(CHARACTERISTICS_FILE, characteristics);
  
  // Remover la característica de todos los productos
  const products = getProducts();
  products.forEach((product) => {
    if (product.characteristics) {
      product.characteristics = product.characteristics.filter((c) => c !== req.params.id);
    }
  });
  writeJson(PRODUCTS_FILE, products);
  
  res.json({ message: 'Característica eliminada correctamente', characteristic: deletedCharacteristic });
});

// Endpoints de usuarios
app.get('/api/admin/users', authMiddleware, adminMiddleware, (req, res) => {
  const users = getUsers();
  // No devolver contraseñas
  const usersData = users.map((u) => {
    const { password, token, ...rest } = u;
    return rest;
  });
  res.json({ users: usersData });
});

app.put('/api/admin/users/:id/profile', authMiddleware, adminMiddleware, (req, res) => {
  const { profile } = req.body;
  // Solo el admin principal puede cambiar perfiles
  if (req.user.username !== 'Roccoadmin67') {
    return res.status(403).json({ error: 'Solo el administrador principal puede cambiar perfiles' });
  }
  if (!['admin', null].includes(profile)) {
    return res.status(400).json({ error: 'Perfil inválido. Debe ser "admin" o null' });
  }
  const users = getUsers();
  const index = users.findIndex((u) => u.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }
  users[index].profile = profile;
  writeJson(USERS_FILE, users);
  const { password, token, ...userData } = users[index];
  res.json({ message: 'Perfil de usuario actualizado', user: userData });
});

function ensureAdminUser() {
  const users = getUsers();
  const adminIndex = users.findIndex((item) => item.username.toLowerCase() === 'roccoadmin67');
  if (adminIndex >= 0) {
    if (users[adminIndex].profile !== 'admin') {
      users[adminIndex].profile = 'admin';
    }
    if (!users[adminIndex].token) {
      users[adminIndex].token = generateId('token');
    }
    writeJson(USERS_FILE, users);
    return;
  }

  const adminUser = {
    id: generateId('user'),
    name: 'Rocco Admin',
    username: 'Roccoadmin67',
    password: 'Roccopelado67',
    balance: 50000,
    profile: 'admin',
    portfolio: {},
    token: generateId('token'),
    createdAt: new Date().toISOString()
  };
  users.push(adminUser);
  writeJson(USERS_FILE, users);
}

// Servir index.html en la ruta raíz
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  ensureDataFiles();
  ensureAdminUser();
  console.log(`Servidor iniciado en http://localhost:${PORT}`);
});
